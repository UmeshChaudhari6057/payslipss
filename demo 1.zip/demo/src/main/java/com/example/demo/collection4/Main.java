package com.example.demo.collection4;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		CaffeineSurvey survey = new CaffeineSurvey();

		System.out.print("Enter number of coffee records: ");
		int n = Integer.parseInt(scanner.nextLine());

		for (int i = 0; i < n; i++) {
			System.out.println("Enter coffee brand name:");
			String brand = scanner.nextLine();

			System.out.println("Enter caffeine percentage:");
			float percentage = Float.parseFloat(scanner.nextLine());

			Caffeine caffeine = new Caffeine(brand, percentage);
			survey.getCoffeeList().add(caffeine);
		}

		System.out.println("\nSorted Coffee Brands:");
		List<Caffeine> sortedList = survey.sortByBrandName();
		for (Caffeine c : sortedList) {
			System.out.println(c.getCoffeeBrand() + " - " + c.getCaffeinePercentage() + "%");
		}

		double avg = survey.getAvgPercentage();
		System.out.printf("\nAverage caffeine percentage: %.2f%%\n", avg);

		scanner.close();
	}
}
