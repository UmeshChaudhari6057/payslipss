package com.example.demo.collection3;

public class Size {
	private int area;

	public Size(int area) {
		this.area = area;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}
}
