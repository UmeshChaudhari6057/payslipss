package com.example.demo.collection2;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		SalesTracker tracker = new SalesTracker();

		System.out.println("Enter number of records to be added");
		int n = Integer.parseInt(scanner.nextLine());

		System.out.println("Enter the records (Customer Name:Product)");
		for (int i = 0; i < n; i++) {
			String record = scanner.nextLine();
			tracker.addSalesRecord(record);
		}

		// Product search for number of customers
		System.out.println("Enter the Product to be searched");
		String searchProduct = scanner.nextLine();
		int count = tracker.findNumberOfCustomersByProduct(searchProduct);
		if (count == -1) {
			System.out.println("No customers found for " + searchProduct);
		} else {
			System.out.println("The number of customers who purchased " + searchProduct + " is " + count);
		}

		// Product search for customer names
		System.out.println("Enter the Product to identify the Customer Names");
		String productForCustomers = scanner.nextLine();
		List<String> customers = tracker.getCustomersByProduct(productForCustomers);
		if (customers.isEmpty()) {
			System.out.println("No customers found for " + productForCustomers);
		} else {
			System.out.println("Customer names who purchased " + productForCustomers + " are");
			System.out.println(String.join(", ", customers));
		}

		// Customer search for product
		System.out.println("Enter the Customer name to find the Product purchased");
		String customerName = scanner.nextLine();
		String product = tracker.getProductByCustomer(customerName);
		if (product == null) {
			System.out.println("No product found for " + customerName);
		} else {
			System.out.println("Product purchased by " + customerName + " is " + product);
		}

		scanner.close();
	}
}
