package com.example.demo.util;

import java.util.Scanner;
import java.util.Stack;

public class Session3 {

	public static void main(String[] args) {

		String expression = "{[()]}";
		boolean isBalanced = true;
		Stack<Character> stack = new Stack<>();
		for (int i = 0; i < expression.length(); i++) {
			char ch = expression.charAt(i);
			if (ch == '(' || ch == '[' || ch == '{') {
				stack.push(ch);
			} else if (ch == ')' || ch == ']' || ch == '}') {
				if (stack.isEmpty()) {
					isBalanced = false;
					break;
				}
				char top = stack.pop();
				if ((ch == '(' && ch != ')') || (ch == '[' && ch != ']') || (ch == '{' && ch != '}')) {
					isBalanced = false;
					break;
				}
			}
		}
		if (!stack.isEmpty()) {
			isBalanced = false;
		}
		System.out.println(isBalanced);

		Scanner sc = new Scanner(System.in);
		System.out.println("Compliment of number(only 1 and 0 are alllowed : ");
		String input = sc.nextLine();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			if (c == '0') {
				sb.append('1');
			} else if (c == '1') {
				sb.append('0');
			}
		}
		System.out.println(sb);

	}
}
