package com.example.demo.util;

import java.util.function.Predicate;

public class PredicateExample {
	
	public static void main(String[] args) {
		
		Predicate<Integer> isEven = number -> number%2 == 0;
		System.out.println(isEven.test(4));
		System.out.println(isEven.test(11));
		
		Predicate<Integer> isOdd = num -> num%2 != 0;
		Predicate<Integer> numberIsGreater = n -> n > 10;
		Predicate<Integer> numberIsOddAndGreaterThan = isOdd.and(numberIsGreater);
		System.out.println(numberIsOddAndGreaterThan.test(15));;
		System.out.println(numberIsOddAndGreaterThan.test(9));
		
		Predicate<Integer> isEvens = n -> n%2 == 0;
		System.out.println(isEvens.test(4));
		Predicate<Integer> isOdds = n-> n%2 != 0;
		System.out.println(isOdds.test(5));
		
		
		
	}

}
