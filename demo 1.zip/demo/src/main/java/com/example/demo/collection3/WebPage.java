package com.example.demo.collection3;

import java.util.*;

public class WebPage {
	public Map<Integer, Map<Size, Content>> page = new HashMap<>();
	public Size totalArea;
	public int index;

	public WebPage(Size totalArea) {
		this.totalArea = totalArea;
		this.index = 0;
	}

	public String addPage(Size size, Content content) {
		if (!checkArea(size)) {
			return "No space";
		}

		Map<Size, Content> entry = new HashMap<>();

		if (canCompress(content)) {
			int compressedArea = compressSize(size);
			Size compressedSize = new Size(compressedArea);
			entry.put(compressedSize, content);
			page.put(index++, entry);
			return "Page added after compress";
		} else {
			entry.put(size, content);
			page.put(index++, entry);
			return "Page added";
		}
	}

	public boolean checkArea(Size size) {
		return totalArea.getArea() >= size.getArea();
	}

	public boolean canCompress(Content content) {
		return content.isImage() && content.getText().length() > 100;
	}

	public int compressSize(Size size) {
		int area = size.getArea();
		if (area > 100) {
			return (int) (area * 0.75);
		} else {
			return area;
		}
	}
}
