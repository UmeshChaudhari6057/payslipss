package com.example.demo.exception3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.println("Enter Name");
			String name = scanner.nextLine();

			System.out.println("Enter Age");
			int age = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter Email");
			String email = scanner.nextLine();

			System.out.println("Enter Credit Card Number");
			String creditCard = scanner.nextLine();

			HotelBooking.validateUserDetails(age, email, creditCard);

			System.out.println("Enter Hotel Name");
			String hotelName = scanner.nextLine();

			System.out.println("Select Room Type");
			String roomType = scanner.nextLine();

			System.out.println("Enter Check-in Date (yyyy-MM-dd)");
			String checkInStr = scanner.nextLine();

			System.out.println("Enter Check-out Date (yyyy-MM-dd)");
			String checkOutStr = scanner.nextLine();

			HotelBooking.validateBookingDetails(hotelName, roomType, checkInStr, checkOutStr);

			System.out.println("Include Breakfast? (yes/no)");
			String breakfastInput = scanner.nextLine();
			boolean breakfastIncluded = breakfastInput.equalsIgnoreCase("yes");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate checkInDate = LocalDate.parse(checkInStr, formatter);
			LocalDate checkOutDate = LocalDate.parse(checkOutStr, formatter);
			int numNights = (int) ChronoUnit.DAYS.between(checkInDate, checkOutDate);

			double totalCost = HotelBooking.calculateBookingCost(roomType, numNights, breakfastIncluded);
			System.out.printf("Total Booking Cost: $%.2f%n", totalCost);

		} catch (InvalidBookingDetailsException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Invalid number format.");
		} finally {
			scanner.close();
		}
	}
}
