package com.example.demo.util;
//First Example
@FunctionalInterface
interface ArithmeticOperation {
	double operate(double a, double b);
}

public class LambdaExpression {

	public static void main(String[] args) {

		ArithmeticOperation add = (a, b) -> a + b;
		ArithmeticOperation subtract = (a, b) -> a - b;
		ArithmeticOperation multiply = (a, b) -> a * b;
		ArithmeticOperation divide = (a, b) -> {
			if (b == 0) {
				throw new ArithmeticException("Division By Zero !!");
			}
			return a / b;
		};

		double num1 = 10.0;
		double num2 = 5.0;

		System.out.println("Addition : " + add.operate(num1, num2));
		System.out.println("Subtraction : " + subtract.operate(num1, num2));
		System.out.println("Multiplication : " + multiply.operate(num1, num2));
		System.out.println("Division : " + divide.operate(num1, num2));
		
		

	}

}
