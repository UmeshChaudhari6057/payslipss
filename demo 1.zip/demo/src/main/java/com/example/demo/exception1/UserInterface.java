package com.example.demo.exception1;

import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.println("Enter Name");
			String name = scanner.nextLine();

			System.out.println("Enter Age");
			int age = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter Gender");
			String gender = scanner.nextLine();

			System.out.println("Enter Height (in meters)");
			double height = Double.parseDouble(scanner.nextLine());

			System.out.println("Enter Weight (in kg)");
			double weight = Double.parseDouble(scanner.nextLine());

			System.out.println("Enter Blood Pressure (mmHg)");
			int bloodPressure = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter Cholesterol Level");
			double cholesterol = Double.parseDouble(scanner.nextLine());

			boolean isValid = HealthDataProcessor.validatePatientDetails(age, gender, height, weight, bloodPressure,
					cholesterol);

			if (isValid) {
				double premium = HealthDataProcessor.calculateInsurancePremium(height, weight, age, bloodPressure,
						cholesterol);
				System.out.println("Total Insurance Premium: $" + premium);
			}

		} catch (InvalidHealthDataException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Invalid input format. Please enter numeric values where required.");
		} finally {
			scanner.close();
		}
	}
}
