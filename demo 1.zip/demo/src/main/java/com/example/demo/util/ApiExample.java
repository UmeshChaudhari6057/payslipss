package com.example.demo.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class ApiExample {

	public static void main(String[] args) {		
		
		List<Integer> task1 = Arrays.asList(13, 9, 99, 5, 24, 6);		
		int result = task1.stream().filter(number -> number%2 !=0 ).mapToInt(Integer::intValue).sum();		
		System.out.println(result);		
				
		int minus = task1.stream().filter(x -> x%2 == 0).mapToInt(Integer::intValue).min().orElse(-1);
		System.out.println(minus);
		
		
		double average = task1.stream().mapToInt(Integer::intValue).average().orElse(-1);
		System.out.println(average);
		task1.stream().mapToInt(Integer::intValue).min().orElse(-1);
		
		List<String> votes = Arrays.asList("a", "c", "d", "a", "b", "d", "d");
		Map<String, Long> voteCountMap = votes.stream().collect(Collectors.groupingBy(v->v, Collectors.counting()));
		Optional<Map.Entry<String, Long>> winner = voteCountMap.entrySet().stream().max(Map.Entry.comparingByValue());
		System.out.println(winner);	
		
		
		String input = "Prajapati";
		Set<Character> set = new HashSet<>();
		Optional<Character> repeatchar = input.chars().mapToObj(ch -> (char)ch)
				.filter(ch -> !set.add(ch))
				.findFirst();
		System.out.println(repeatchar);
		
		Optional<Character> notRepeatChar = input.chars().mapToObj(cha -> (char)cha)
				.collect(Collectors.groupingBy(z->z, LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(entry->entry.getValue() == 1)
				.map(Map.Entry::getKey)
				.findFirst();
		System.out.println(notRepeatChar);
		
		int original = 12121;
		int num = original;
		int reverse = 0;
		while(num > 0) {
			int digit = num % 10;
			reverse = reverse * 10 + digit;
			num /= 10;
		}
		System.out.println(num == reverse);
		
		
		
		
		//find duplicate element frequency from array
        int[] arr = {1, 2, 3, 2, 4, 5, 6, 4, 4, 6, 7, 8, 2};
        Map<Integer, Long> freqMap = Arrays.stream(arr).boxed().collect(Collectors.groupingBy(a->a, Collectors.counting()));
        freqMap.entrySet().stream().filter(entry -> entry.getValue() > 1).forEach(System.out::println); 
       
	}

}

