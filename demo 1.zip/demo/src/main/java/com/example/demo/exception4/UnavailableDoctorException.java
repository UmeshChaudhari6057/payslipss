package com.example.demo.exception4;

public class UnavailableDoctorException extends Exception {
    public UnavailableDoctorException(String message) {
        super(message);
    }
}

