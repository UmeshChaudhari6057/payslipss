package com.example.demo.movie;

import java.util.*;
import java.util.stream.*;

public class MovieCatalogUtility {

	public Map<String, List<Movie>> retrieveMoviesGroupedByGenre(Stream<Movie> movies) {
		return movies.collect(Collectors.groupingBy(Movie::getGenre));
	}

	public Map<String, Double> getDirectorsAndPricesByTitle(Stream<Movie> movies, String title) {
		return movies.filter(m -> m.getTitle().equals(title))
				.collect(Collectors.toMap(Movie::getDirector, Movie::getRentalPrice));
	}

	public double calculateLateFees(List<Rental> rentals, int daysLate) {
		double lateFeePerDay = 1.5; // fixed rate
		return rentals.size() * daysLate * lateFeePerDay;
	}

	public Stream<String> generateSummaryReport(List<Movie> movies) {
		long totalMovies = movies.size();
		double totalRevenue = movies.stream().mapToDouble(m -> m.getRentalPrice() * m.getQuantityAvailable()).sum();
		double averagePrice = movies.stream().mapToDouble(Movie::getRentalPrice).average().orElse(0.0);

		return Stream.of("Total movies: " + totalMovies, "Total revenue: " + String.format("%.2f", totalRevenue),
				"Average price: " + String.format("%.2f", averagePrice));
	}

	public List<Movie> searchMoviesByDirector(Stream<Movie> movies, String directorName) {
		return movies.filter(m -> m.getDirector().equals(directorName)).collect(Collectors.toList());
	}

	public List<Movie> sortMoviesByPrice(Stream<Movie> movies, boolean ascendingOrder) {
		Comparator<Movie> comparator = Comparator.comparingDouble(Movie::getRentalPrice);
		if (!ascendingOrder) {
			comparator = comparator.reversed();
		}
		return movies.sorted(comparator).collect(Collectors.toList());
	}

}
