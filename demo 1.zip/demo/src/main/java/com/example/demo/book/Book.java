package com.example.demo.book;

public class Book {

	private String bookId;
	private String title;
	private String author;
	private String genre;
	private double price;
	private boolean available;

	public Book() {
	}

	public Book(String bookId, String title, String author, String genre, double price, boolean available) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.price = price;
		this.available = available;
	}

	// Getters and Setters
	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	@Override
	public String toString() {
		return bookId + " " + title + " " + author + " " + genre + " " + price + " " + available;
	}

}
