package com.example.demo.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Session2 {

	public static void main(String[] args) {

		Map<String, Integer> fruitMap = new HashMap<>();
		fruitMap.put("Apple", 60);
		fruitMap.put("Banana", 25);
		fruitMap.put("Pine-Apple", 50);
		fruitMap.put("Grapes", 80);
		fruitMap.put("Mango", 60);

		Map<String, Integer> sortedMap = fruitMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue, LinkedHashMap::new));
		System.out.println(sortedMap);
		
		Map<String, Integer> fruMap = fruitMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue, LinkedHashMap::new));
		System.out.println(fruMap);

		int matrix[][] = {{1,2,3,4},
				{5,6,7,8},
				{9,1,2,3},
				{5,7,2,1}
		};
		int sumOfBorderedEle = 0;
		int rows = matrix.length;
		int cols = matrix[0].length;

		for(int i = 0 ; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				if( i == 0 || i == rows-1 || j == 0 || j == cols-1) {
					sumOfBorderedEle += matrix[i][j];
				}
			}				
		}
		System.out.println(sumOfBorderedEle);

		
		int x = 5;
		for(int i = 1; i <= x; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		
		int y = 5;
		for(int i = 1; i <= y; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}


		int array[] = {1,2,3,4,5,6,7,2,4,6,1};
		int maxSum = 0;		
		int currentSum = 0;
		for(int i = 0; i < array.length-2; i++) {
			currentSum = array[i]+array[i+1]+array[i+2];
			if(currentSum > maxSum) {
				maxSum = currentSum;				
			}
		}
		System.out.println(maxSum);


		List<Integer> list1 = Arrays.asList(1,2,3,4,5,6,7,8,9,10,11);
		Map<Integer, List<Integer>> groupMap = list1.stream().collect(Collectors.groupingBy(n -> n%2 == 0 ? 1 : 2));
		System.out.println(groupMap);


		String input = "Tiya";
		String rev = "";
		char[] ch = input.toCharArray();
		for(int i = ch.length-1; i >= 0; i--) {
			rev += ch[i];
		}
		System.out.println(rev);
		Object[] arrObj = {rev.length()};
		System.out.println(arrObj[0]); 

		String input2 = "India is my country I love my country";
		List<String> list3 = Arrays.asList(input2.split(" "));
		Map<String, Long> map1 = list3.stream().collect(Collectors.groupingBy(v->v, Collectors.counting()));
		System.out.println(map1);

		List<String> list4 = Arrays.asList("rose","Chemeli","Lotus","sunflower","Mogra");
		Optional<String> output = list4.stream().max(Comparator.comparing(String::length));
		System.out.println(output);

		List<Integer> list5 = Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12);
		List<Integer> list6 = Stream.concat(list5.stream().filter(n->n%2==0), list5.stream().filter(n->n%2!=0)).toList();
		System.out.println(list6);

		Map<String, Integer> map2 = new HashMap<>();
		map2.put("Lilly", 10);
		map2.put("rose", 45);
		map2.put("Mari", 20);
		Map<String,Integer>map3 = map2.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
		System.out.println(map3);

		int original = 12121;
		int num = original;
		int reverse = 0;
		while(num > 0) {
			int digit = num % 10;
			reverse = reverse * 10 + digit;
			num /= 10;
		}
		System.out.println(original == reverse);


		Map<String, Integer> flowerMap = new HashMap<>();
		flowerMap.put("Lilly", 80);
		flowerMap.put("Lotus", 40);
		flowerMap.put("Rose", 55);
		flowerMap.put("Sunflower", 10);
		flowerMap.put("Mogara", 35);
		Map<String, Integer> map5 = flowerMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue, LinkedHashMap::new));
		System.out.println(map5);

		List<Integer> list8 = Arrays.asList(1,2,3,4,3,4,6,8,1,2);
		List<Integer> list9 = list8.stream().distinct().toList();
		System.out.println(list9);

		List<Integer> list10 = Arrays.asList(1,2,3,4,5,4,6,3,1);
		Set<Integer> set = new HashSet<>();
		List<Integer> duplicateList = list10.stream().filter(i -> !set.add(i)).toList();
		System.out.println(duplicateList);
		
		int array1[] = {1,28,32,13,8,44,9};
		int k = 3;
		int ksmall = Arrays.stream(array1).sorted().skip(k-1).findFirst().orElse(0);
		System.out.println(ksmall);

		int fourthsmall = Arrays.stream(array1).sorted().skip(4-1).findFirst().orElse(0);
		System.out.println(fourthsmall);


		int input3 = 29;
		if(input3 <= 2) {
			System.out.println("not a prime number");
		}else {
			boolean result = IntStream.rangeClosed(2, (int)Math.sqrt(input3)).noneMatch(n -> input3%2 == 0);
			System.out.println(result);
		}

		int array2[] = {1,2,3,56,78,12,10};
		int firstLargest = Integer.MIN_VALUE;
		int secondLargest = Integer.MIN_VALUE;
		for(int numbers : array2) {
			if(numbers > firstLargest) {
				secondLargest = firstLargest;
				firstLargest = numbers;
			}else if(numbers > secondLargest && firstLargest != numbers) {
				secondLargest = numbers;
			}
		}
		System.out.println(secondLargest);
		
		
		Map<String, Integer> fruiMap = new HashMap<>();
		fruiMap.put("Apple", 60);
		fruiMap.put("Banana", 25);
		fruiMap.put("Pine-Apple", 50);
		fruiMap.put("Mango", 60);
		
		Map<String, Integer> sorMap = fruiMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue, LinkedHashMap::new ));
		System.out.println(sorMap);
		
		String input5 = "population";
		Map<Object, Long> countOfEachChar = input5.chars().mapToObj(cha -> (char)cha).collect(Collectors.groupingBy(v->v, Collectors.counting()));
		System.out.println(countOfEachChar);
	
		String input6 = "Teena";
		Optional<Character> notrepeat = input6.chars().mapToObj(chars->(char)chars).collect(Collectors.groupingBy(v->v, LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(entry->entry.getValue() == 1)
				.map(Map.Entry::getKey).findFirst();		
		System.out.println(notrepeat);
		
		Optional<Character> firstRepeat = input6.chars().mapToObj(c -> (char)c).collect(Collectors.groupingBy(v->v, LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(entry->entry.getValue() > 1).map(Map.Entry::getKey).findFirst();
		System.out.println(firstRepeat);
		
		List<Character>duplicateCharsList = input6.chars().mapToObj(ca -> (char)ca).collect(Collectors.groupingBy(v->v, Collectors.counting()))
				.entrySet().stream().filter(entry->entry.getValue() > 1).map(Map.Entry::getKey).toList();
		System.out.println(duplicateCharsList);
		
		List<String> input7 = Arrays.asList("a","b","c","d","e","i","a","b","a","i");
		Map<String, Long> countOfChars = input7.stream().collect(Collectors.groupingBy(v->v, Collectors.counting()));
		System.out.println(countOfChars);
		
		String input8 = "India is my country I love my country";
		List<String> list11 = Arrays.asList(input8.split(" "));
		Map<String, Long> eachWordCount = list11.stream().collect(Collectors.groupingBy(v->v, Collectors.counting()));
		System.out.println(eachWordCount);
		
		String input9 = "Tiya";
		String reverseString = "";
		char a[] = input9.toCharArray();
		for(int i = a.length-1; i >= 0; i--) {
			reverseString+=a[i];
		}
		System.out.println(reverseString);
		
		Object[] lengthArr = {reverseString.length()};
		System.out.println(lengthArr[0]);
		
		int input10 = 5;
		for(int i = 1; i <= input10; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		
		int input11 = 6;
		for(int i = 1; i <= input11; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print("*" + " ");				
			}
			System.out.println();
		}
		
		int matrixs[][] = {{1,2,3,4},{4,5,6,7},{8,9,0,1},{2,3,4,5}};
		int sumOfElements = 0;
		int row = matrixs.length;
		int col = matrixs[0].length;
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < col; j++) {
				//if(i == 0 || i == row-1 || j == 0 || j == col-1) {
					sumOfElements+=matrixs[i][j];
				//}
			}
		}
		System.out.println(sumOfElements);
		
		int array3[] = {1,2,3,4,56,7,8,9,0};		
		int masum = 0;
		for(int i = 0; i < array3.length-2; i++) {
			int currSum = array3[i]+array3[i+1]+array3[i+2];
			if(currSum > masum) {
				masum = currSum;				
			}
		}
		System.out.println(masum);
		
		int origin = 12121;
		int num1 = origin;
		int revers = 0;
		while(num1 > 0) {
			int digit = num1 % 10;
			revers = revers * 10 + digit;
			num1 /= 10;
		}
		System.out.println(origin==revers);
		
		int num2 = 29;
		if(num2 <= 2) {
			System.out.println("not prime");
		}else {
			boolean re = IntStream.rangeClosed(2, (int)Math.sqrt(num2)).noneMatch(n -> num2%2 == 0);		
			System.out.println(re);
		}
		
				
				int array4[] = {1,2,3,4,4,10,10,10};
				int first = Integer.MIN_VALUE;
				int second = Integer.MIN_VALUE;
				for(int num4 : array3) {
					if(num4 > first) {
						second = first;
						first = num4;
					}else if(num4 > second && num4 != first) {
						second = num4;
					}
				}
		

				try {
					int num7 = 10/0;
				} 
				catch (ArithmeticException e) {
					System.out.print("ArithmaticExecption Execption");
				}catch (RuntimeException e) {
					System.out.print("Runtime Execption");
				}catch (Exception e){
					System.out.print("Exception");
				}

				List<String> list = Arrays.asList("array", "apple", "rat");
				String result = list.stream().map(word -> {
					Map<Character, Long> charCount = word.chars().mapToObj(g -> (char)g)
							.collect(Collectors.groupingBy(c->c, LinkedHashMap::new, Collectors.counting()));			

					return charCount.entrySet().stream()
							.filter(e -> e.getValue() == 1)
							.map(e -> String.valueOf(e.getKey()))
							.findFirst()
							.orElse("");
					})
						.collect(Collectors.joining(","));
						System.out.println(result); 
				
				
}

}
