package com.example.demo.util;

import org.w3c.dom.css.Counter;

// write a thread safe singleton class

public class Singleton{
	private static Singleton instance;
	private Singleton(){}
	public static synchronized Singleton getInstance(){
		if(instance == null){
			instance = new Singleton();			
		}
		return instance;
	}
	
}





//public class ThreadSafeSingleton {
//
//    private static ThreadSafeSingleton instance;
//
//    private ThreadSafeSingleton(){}
//
//    public static synchronized ThreadSafeSingleton getInstance() {
//        if (instance == null) {
//            instance = new ThreadSafeSingleton();
//        }
//        return instance;
//    }
//
//}

//public class MyThread implements Runnable{
//	
//	@override
//	public void run() {
//		for(int i = 0; i < 5; i++) {
//			System.out.println("Hello");
//			try {
//				Thread.sleep(500);
//			}catch(Interrupted Exception e) {
//				e.printStackTrace();
//			}
//		}	
//	}
//}
//
//public class HelloThread{
//	
//	public static void main(String[] args) {
//		Thread thread = new Thread(new MyThread());
//		thread.start();
//	}
//}

//public class ThreadSafeSingleton {
//
//	private static ThreadSafeSingleton instance;
//
//	private ThreadSafeSingleton() {
//	}
//
//	public static synchronized ThreadSafeSingleton getInstance
//	{
//
//		if (instance == null) {
//			instance = new ThreadSafesingleton();
//		}
//
//		return instance;
//	}
//}


