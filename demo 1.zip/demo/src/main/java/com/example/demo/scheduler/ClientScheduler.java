package com.example.demo.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ClientScheduler {

	@Scheduled(fixedRate = 5000)
	public void scheduledTask() {
		System.out.println("Executing scheduled task every 5 seconds...");
	}

}
