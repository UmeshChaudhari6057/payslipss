package com.example.demo.employee;

import java.util.*;
import java.util.stream.*;

public class EmployeeUtility {

	public Stream<Employee> getEmployeesByDepartment(Stream<Employee> employeeStream, String department) {
		return employeeStream.filter(e -> e.getDepartment().equalsIgnoreCase(department));
	}

	public List<Employee> getEmployeesByLocation(Stream<Employee> employeeStream, String location) {
		return employeeStream.filter(e -> e.getLocation().equalsIgnoreCase(location)).collect(Collectors.toList());
	}

	public Stream<Employee> getEmployeesInSalaryRange(List<Employee> employeeList, double minSalary, double maxSalary) {
		if (minSalary > maxSalary)
			return Stream.empty();
		return employeeList.stream().filter(e -> e.getSalary() >= minSalary && e.getSalary() <= maxSalary);
	}

}
