package com.example.demo.stream;

public class Transaction {

	Trader trader;
	int year;
	int value;

	Transaction(Trader trader, int year, int value) {
		this.trader = trader;
		this.year = year;
		this.value = value;
	}

	public String toString() {
		return trader.name + " - " + value;
	}

}
