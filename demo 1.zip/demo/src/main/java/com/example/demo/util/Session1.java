package com.example.demo.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Session1 {

	public static void main(String[] args) {

		/* find out sum of odd number from given list */
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		int sumOfOddNumber = list.stream().filter(n -> n % 2 != 0).mapToInt(Integer::intValue).sum();
		System.out.println(sumOfOddNumber); //for(int num : list){ sum+=num;}

		/* find out lowest number from given list */
		List<Integer> list1 = Arrays.asList(121, 342, 13, 125, 558);
		int lowestNumber = list1.stream().mapToInt(Integer::intValue).min().orElse(0);
		System.out.println(lowestNumber); //int min = Integer.MAX_VALUE for(int num : list){ min = num}

		/* find out winner from below list of character */
		List<String> list2 = Arrays.asList("a", "b", "c", "d", "e", "i", "a", "i", "i", "s");
		Map<String, Long> winnerMap = list2.stream().collect(Collectors.groupingBy(v -> v, Collectors.counting()));
		Optional<Map.Entry<String, Long>> winner = winnerMap.entrySet().stream().max(Map.Entry.comparingByValue());
		System.out.println(winner);

		/* get count of each character of given string */
		String input = "Sayalee";
		Map<Object, Long> eachCharCount = input.chars().mapToObj(ch -> (char) ch)
				.collect(Collectors.groupingBy(j -> j, Collectors.counting()));
		System.out.println(eachCharCount);

		/* get list of duplicate chars from given string */
		String input1 = "population";
		List<Character> duplicateChars = input1.chars().mapToObj(cha -> (char) cha)
				.collect(Collectors.groupingBy(k -> k, Collectors.counting())).entrySet().stream()
				.filter(entry -> entry.getValue() > 1).map(Map.Entry::getKey).toList();
		System.out.println(duplicateChars);

		/* find first repeatative char from given string */
		String input2 = "Kumbharaj";
		Optional<Character> firstRepeatativeChar = input2.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(m -> m, LinkedHashMap::new, Collectors.counting())).entrySet().stream()
				.filter(entry -> entry.getValue() > 1).map(Map.Entry::getKey).findFirst();
		System.out.println(firstRepeatativeChar);

		/* find first non-repeatative char from given string */
		String input3 = "Dwaraka";
		Optional<Character> firstNotRepeatativeChar = input3.chars().mapToObj(s -> (char) s)
				.collect(Collectors.groupingBy(n -> n, LinkedHashMap::new, Collectors.counting())).entrySet().stream()
				.filter(entry -> entry.getValue() == 1).map(Map.Entry::getKey).findFirst();
		System.out.println(firstNotRepeatativeChar);

		/* Create a map for odd number and even number with 1 and 2 key respectively */
		List<Integer> list3 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		Map<Integer, List<Integer>> groupedNumbers = list3.stream()
				.collect(Collectors.groupingBy(n -> n % 2 == 0 ? 1 : 2));
		System.out.println(groupedNumbers);		

		/* count number of words from given string and output is map format */
		String input4 = "India is my country I love my country";
		List<String> list4 = Arrays.asList(input4.split(" "));
		Map<String, Long> countOfEachWord = list4.stream()
				.collect(Collectors.groupingBy(q -> q, Collectors.counting()));
		System.out.println(countOfEachWord);

		/* find out max length of String from give list */
		List<String> list5 = Arrays.asList("banana", "sunflower", "Onion", "Lotus", "peanut-butter", "gauva");
		Optional<String> maxLengthstring = list5.stream().max(Comparator.comparing(String::length));
		System.out.println(maxLengthstring);

		/* reverse the given string and count of reverse string in array format */
		String input5 = "Tiya";
		String rev = "";
		char[] ch = input5.toCharArray();
		for (int i = ch.length - 1; i >= 0; i--) {
			rev += ch[i];
		}
		System.out.println(rev);
		Object[] charArr = { rev, rev.length() };
		System.out.println(charArr[1]);		

		/* find out sum of bordered elements from given matrix */
		int matrix[][] = { { 1, 2, 3, 4 }, { 5, 6, 7, 8 }, { 9, 1, 2, 3 }, { 4, 5, 6, 7 } };

		int borderedElementSum = 0;
		int rows = matrix.length;
		int cols = matrix[0].length;

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (i == 0 || i == rows - 1 || j == 0 || j == cols - 1) {
					borderedElementSum += matrix[i][j];
				}
			}
		}
		System.out.println("Sum of border elements : " + borderedElementSum);

		/* print given number pattern */
		int x = 5;
		for (int i = 1; i <= x; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print("*" + " ");
			}
			System.out.println();
		}
		
		
		/*find out max sum of three consecutive number */
		int array[] = {1, 2, 3, 8, 23, 43, 2, 4, 5, 7, 8};
		int maxSum = 0;
	    int startIndex = 0;
		for(int i = 0; i < array.length-2; i++) {
			int currentSum = array[i] + array[i+1] + array[i+2];
			if(currentSum > maxSum) {
				maxSum = currentSum;
				startIndex = i;
			}			
		}
		System.out.println(maxSum);
		System.out.println("ELements are : " + array[startIndex] + array[startIndex+1] + array[startIndex+2]);
		
		//From below list get only one list whose contain first odd numbers and second even numbers in only one list
		List<Integer> list6 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		List<Integer> result = Stream
				.concat(list6.stream().filter(n -> n % 2 != 0), list6.stream().filter(n -> n % 2 == 0))
				.collect(Collectors.toList());
		System.out.println(result);
		
		//Create a simple hashmap with key value pair and print it
		Map<String, Integer> inputMap = new HashMap<>();
		inputMap.put("Lotus", 10);
		inputMap.put("Rose", 24);
		inputMap.put("Sunflower", 90);

		Map<String, Integer> outPutMap = inputMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		System.out.println(outPutMap);
		
		//check a below number is palindrom or not
		int original = 12121;
		int num  = original;
		int reverse = 0;
		while(num > 0) {
			int digit = num % 10;
			reverse = reverse * 10 + digit;
			num /= 10;
		}
		System.out.println(original == reverse);
		
		//sorted below map according to value ascending order
		Map<String, Integer> flowerMap = new HashMap<>();
		flowerMap.put("Lilly", 80);
		flowerMap.put("Lotus", 40);
		flowerMap.put("Rose", 55);
		flowerMap.put("Sunflower", 10);
		flowerMap.put("Mogara", 35);
		
		Map<String, Integer> sortedFlowerMap = flowerMap.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue) -> oldValue, LinkedHashMap::new));
		System.out.println(sortedFlowerMap);
		
		
		// remove duplicates from the list
		List<Integer> list7 = Arrays.asList(12, 2, 3, 5, 5, 1, 12, 3, 4, 5, 7, 2);
		List<Integer> distinctNumbers = list7.stream().distinct().toList();
		System.out.println(distinctNumbers);

		// find duplicates from the list
		Set<Integer> set = new HashSet<>();
		List<Integer> duplicateList = list.stream().filter(z -> !set.add(z)).toList();
		System.out.println(duplicateList);		
		
		// find Kth smallest element in an array using java stream
		int array1[] = { 4, 2, 7, 1, 5, 3, 6 };
		int k = 3;
		int smallestElement = Arrays.stream(array1).sorted().skip(k-1).findFirst().orElse(-1);
		System.out.println(smallestElement);
				
		// second largest element from aaray;
		int array2[] = { 1, 2, 3, 4, 5 };
		int i = array2.length;
		int secondLargestElement = Arrays.stream(array2).sorted().skip(i-2).findFirst().orElse(-1);
		System.out.println(secondLargestElement);				
		
		// below given number is prime number
		int number = 29;
		if(number <= 2) {
			System.out.println("not prime");
		}else {
			boolean result1 = IntStream.rangeClosed(2, (int)Math.sqrt(number)).noneMatch(s -> number%s == 0);
			System.out.println(result1);			
		}		
		
		// find second largest
		int arr[] = {1, 2, 3, 4, 4, 4, 10, 10, 10};
		int firstLargest = Integer.MIN_VALUE;
		int secondLargest = Integer.MIN_VALUE;

		// Traverse the array
		for (int numbers : arr) {
			if (numbers > firstLargest) {
				secondLargest = firstLargest; // Update second largest
				firstLargest = numbers; // Update first largest
			} else if (numbers > secondLargest && numbers != firstLargest) {
				secondLargest = numbers; // Update second largest if new number is unique
			}
		}
		System.out.println(secondLargest);				
		
		
		//find count of each character
		List<String> list8 = Arrays.asList("a","b","c","a", "b","i");
		Map<String, Long> countOfEachString = list8.stream().collect(Collectors.groupingBy(v->v, Collectors.counting()));
		System.out.println(countOfEachString);
				
		//filter out char whose count is 1 
		List<String> out = countOfEachString.entrySet().stream().filter(entry -> entry.getValue() == 1)
		.map(Map.Entry::getKey).toList();
		System.out.println(out);
		
		//merge below two arrays and show output like this [1,2,3,5,6]
		 int array3[] = {1, 2, 3, 0, 0, 0};
	     int array4[] = {2, 5, 6};
	        
	     // Merge using Streams
	     int[] mergedArray = IntStream.concat(
	    		 Arrays.stream(array3).limit(3), // Consider only the first 3 elements of arr
	             Arrays.stream(array4)
	     ).sorted().toArray();	        
	     System.out.println("Merged and Sorted Array: " + Arrays.toString(mergedArray));
	     
	     
	   //find duplicate element frequency from array
	     int[] array5 = {1, 2, 3, 2, 4, 5, 6, 4, 4, 6, 7, 8, 2};
	     Map<Integer, Long> freqMap = Arrays.stream(array5).boxed().collect(Collectors.groupingBy(a->a, Collectors.counting()));
	     freqMap.entrySet().stream().filter(entry -> entry.getValue() > 1).forEach(System.out::println); 
	     
	     //Findout unique vowels from given string
	     String input9 = "Sayalee";
	     Set<Character> vowelsSet = input9.chars().mapToObj(chars -> (char)chars)
	    		 .filter(e -> "aeiou".indexOf(e) != -1)
	    		 .collect(Collectors.toSet());
	     System.out.println(vowelsSet);	     
	     
	     List<Integer> nums = Arrays.asList(10, 30, 50, 20, 40);
			int secondLargestNum = nums.stream().sorted().skip(nums.size() - 2).findFirst().orElse(0);
			System.out.println(secondLargestNum);
			

			// ["Java", "is", "awesome", "Stream", "API", "is", "powerful"]
			List<String> sentences = Arrays.asList("Java is awesome", "Stream API is powerful");

			List<String> words = sentences.stream().flatMap(sentence -> Arrays.stream(sentence.split(" ")))
					.collect(Collectors.toList());
			System.out.println(words);
			
			
			
	     
//		Find the postion of the element in Array2
//		[100, 90, 85, 65, 45, 35] => Array1
//		[20, 45, 65, 80, 102] => Array2
//		Answer :  [7, 5, 4, 4, 1]

			int arr1[] = { 100, 90, 85, 65, 45, 35 };
			int arr2[] = { 20, 45, 65, 80, 102 };

			for (int numbers : arr2) {
				int position = 1; // 1-based index
				for (int value : arr1) {
					if (numbers < value) {
						position++;
					} else {
						break;
					}
				}
				System.out.print(position + " ");
			}
			
			// 7. First Non-repeated character from the String
			// Ex:
			// Input : { "array", "apple", "rat"}
			// Output: y,a,r
			List<String> list15 = Arrays.asList("array", "apple", "rat");
			String result1 = list15.stream().map(word -> {
				Map<Character, Long> charCount = word.chars().mapToObj(g -> (char)g)
						.collect(Collectors.groupingBy(c->c, LinkedHashMap::new, Collectors.counting()));			

				return charCount.entrySet().stream()
						.filter(e -> e.getValue() == 1)
						.map(e -> String.valueOf(e.getKey()))
						.findFirst()
						.orElse("");
				})
					.collect(Collectors.joining(","));
					System.out.println(result1); 
			/**********************************************************************************/		
					String input16 = "20,10,30,15,19,22,20,30,8,9,10,5, ,7,+,&&,90,11,=";
					// Split and filter valid integers
					List<Integer> numbers = Arrays.stream(input16.split(","))
							.map(String::trim)
							.filter(s -> s.matches("\\d+")) 
							.map(Integer::parseInt).collect(Collectors.toList());					
					
					// Even numbers ascending
					List<Integer> evens = numbers.stream()
					.filter(n -> n % 2 == 0)
					.sorted()
					.collect(Collectors.toList());

					// Odd numbers descending
					List<Integer> odds = numbers.stream()
					.filter(n -> n % 2 != 0)
					.sorted(Comparator.reverseOrder())
					.collect(Collectors.toList());

					 System.out.println("Even Numbers Ascending: " + evens);
					System.out.println("Odd Numbers Descending: " + odds);

		
	}

}
