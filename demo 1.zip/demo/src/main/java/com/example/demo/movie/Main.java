package com.example.demo.movie;

import java.time.LocalDate;
import java.util.*;


public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		MovieCatalogUtility utility = new MovieCatalogUtility();

		System.out.println("Enter the number of movies you want to add:");
		int n = Integer.parseInt(scanner.nextLine());

		List<Movie> movieList = new ArrayList<>();
		System.out.println("Enter the details of the movies (title:genre:director:quantity:price):");
		for (int i = 0; i < n; i++) {
			String[] parts = scanner.nextLine().split(":");
			movieList.add(
					new Movie(parts[0], parts[1], parts[2], Integer.parseInt(parts[3]), Double.parseDouble(parts[4])));
		}

		// 1. Group by genre
		System.out.println("\nMovies grouped by genre:");
		Map<String, List<Movie>> groupedByGenre = utility.retrieveMoviesGroupedByGenre(movieList.stream());
		groupedByGenre.forEach((genre, movies) -> {
			System.out.println(genre);
			movies.forEach(m -> System.out.println(
					m.getTitle() + " " + m.getQuantityAvailable() + " " + m.getDirector() + " " + m.getRentalPrice()));
		});

		// 2. Get directors and prices by title
		System.out.println("\nEnter movie title to get directors and prices:");
		String title = scanner.nextLine();
		Map<String, Double> directorsAndPrices = utility.getDirectorsAndPricesByTitle(movieList.stream(), title);
		System.out.println("\nDirectors and prices of " + title + ":");
		directorsAndPrices.forEach((director, price) -> System.out.println(director + " " + price));

		// 3. Search by director
		System.out.println("\nEnter director name to search movies:");
		String directorName = scanner.nextLine();
		List<Movie> byDirector = utility.searchMoviesByDirector(movieList.stream(), directorName);
		System.out.println("\nMovies directed by " + directorName + ":");
		byDirector.forEach(m -> System.out.println(
				m.getTitle() + " " + m.getGenre() + " " + m.getQuantityAvailable() + " " + m.getRentalPrice()));

		// 4. Summary report
		System.out.println("\nSummary Report:");
		utility.generateSummaryReport(movieList).forEach(System.out::println);

		// 5. Sort by price
		System.out.println("\nMovies sorted by rental price (ascending):");
		List<Movie> sortedMovies = utility.sortMoviesByPrice(movieList.stream(), true);
		sortedMovies.forEach(m -> System.out.println(
				m.getTitle() + " " + m.getGenre() + " " + m.getQuantityAvailable() + " " + m.getRentalPrice()));

		// 6. Late fee calculation (example)
		List<Rental> rentals = Arrays.asList(new Rental("Alice", "Inception", LocalDate.now().minusDays(5), 3),
				new Rental("Bob", "Joker", LocalDate.now().minusDays(4), 2));
		double lateFees = utility.calculateLateFees(rentals, 2);
		System.out.println("\nTotal late fees for 2 days late: " + lateFees);

	}

}
