package com.example.demo.exception3;

public class InvalidBookingDetailsException extends Exception {
	public InvalidBookingDetailsException(String message) {
		super(message);
	}
}
