package com.example.demo.stream;

class Fruit {
	String name;
	int calories;
	int price;
	String color;

	Fruit(String name, int calories, int price, String color) {
		this.name = name;
		this.calories = calories;
		this.price = price;
		this.color = color;
	}

	public String toString() {
		return name;
	}

}
