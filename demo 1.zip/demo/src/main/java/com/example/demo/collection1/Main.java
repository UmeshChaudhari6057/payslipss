package com.example.demo.collection1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		AccountManager manager = new AccountManager();

		while (true) {
			System.out.print("\nEnter action (register, login, reset password, update email, delete user, exit): ");
			String action = scanner.nextLine().trim().toLowerCase();

			switch (action) {
			case "register":
				System.out.print("Enter username: ");
				String regUsername = scanner.nextLine();
				System.out.print("Enter password: ");
				String regPassword = scanner.nextLine();
				System.out.print("Enter email: ");
				String regEmail = scanner.nextLine();
				if (manager.registerUser(regUsername, regPassword, regEmail)) {
					System.out.println("User registered successfully.");
				} else {
					System.out.println("Username or email already exists.");
				}
				break;

			case "login":
				System.out.print("Enter username: ");
				String loginUsername = scanner.nextLine();
				System.out.print("Enter password: ");
				String loginPassword = scanner.nextLine();
				User loggedInUser = manager.login(loginUsername, loginPassword);
				if (loggedInUser != null) {
					System.out.println("Login successful. Welcome, " + loggedInUser.getUsername() + "!");
				} else {
					System.out.println("Invalid credentials. Please try again.");
				}
				break;

			case "reset password":
				System.out.print("Enter username: ");
				String resetUsername = scanner.nextLine();
				System.out.print("Enter new password: ");
				String newPassword = scanner.nextLine();
				if (manager.resetPassword(resetUsername, newPassword)) {
					System.out.println("Password reset successful.");
				} else {
					System.out.println("User not found.");
				}
				break;

			case "update email":
				System.out.print("Enter username: ");
				String updateUsername = scanner.nextLine();
				System.out.print("Enter new email: ");
				String newEmail = scanner.nextLine();
				if (manager.updateEmail(updateUsername, newEmail)) {
					System.out.println("Email updated successfully.");
				} else {
					System.out.println("User not found.");
				}
				break;

			case "delete user":
				System.out.print("Enter username: ");
				String delUsername = scanner.nextLine();
				System.out.print("Are you sure you want to delete user '" + delUsername + "'? (yes/no): ");
				String confirm = scanner.nextLine();
				if (confirm.equalsIgnoreCase("yes")) {
					if (manager.deleteUser(delUsername)) {
						System.out.println("User '" + delUsername + "' deleted successfully.");
					} else {
						System.out.println("User not found.");
					}
				} else {
					System.out.println("Deletion cancelled.");
				}
				break;

			case "exit":
				System.out.println("Exiting program.");
				scanner.close();
				return;

			default:
				System.out.println("Invalid action. Please try again.");
			}
		}
	}
}
