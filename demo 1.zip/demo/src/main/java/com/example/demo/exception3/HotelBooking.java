package com.example.demo.exception3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

public class HotelBooking {

	private static final List<String> VALID_HOTELS = Arrays.asList("Hilton", "Marriott", "Taj", "Hyatt");
	private static final List<String> VALID_ROOM_TYPES = Arrays.asList("Standard", "Deluxe", "Suite");

	public static void validateUserDetails(int age, String email, String creditCard)
			throws InvalidBookingDetailsException {
		if (age < 18 || age > 100) {
			throw new InvalidBookingDetailsException("Invalid age");
		}

		if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
			throw new InvalidBookingDetailsException("Invalid email");
		}

		if (!creditCard.matches("\\d{16}")) {
			throw new InvalidBookingDetailsException("Invalid credit card number");
		}
	}

	public static void validateBookingDetails(String hotelName, String roomType, String checkInStr, String checkOutStr)
			throws InvalidBookingDetailsException {

		if (!VALID_HOTELS.contains(hotelName)) {
			throw new InvalidBookingDetailsException("Invalid hotel name");
		}

		if (!VALID_ROOM_TYPES.contains(roomType)) {
			throw new InvalidBookingDetailsException("Invalid room type");
		}

		LocalDate checkInDate;
		LocalDate checkOutDate;

		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			checkInDate = LocalDate.parse(checkInStr, formatter);
			checkOutDate = LocalDate.parse(checkOutStr, formatter);
		} catch (DateTimeParseException e) {
			throw new InvalidBookingDetailsException("Invalid date format");
		}

		if (!checkInDate.isAfter(LocalDate.now())) {
			throw new InvalidBookingDetailsException("Invalid check-in date");
		}

		if (!checkOutDate.isAfter(checkInDate)) {
			throw new InvalidBookingDetailsException("Invalid check-out date");
		}
	}

	public static double calculateBookingCost(String roomType, int numNights, boolean breakfastIncluded) {
		int ratePerNight = 0;

		switch (roomType) {
		case "Standard":
			ratePerNight = 1000;
			break;
		case "Deluxe":
			ratePerNight = 2000;
			break;
		case "Suite":
			ratePerNight = 3000;
			break;
		}

		int breakfastCost = breakfastIncluded ? 100 : 0;
		return (ratePerNight + breakfastCost) * numNights;
	}
}
