package com.example.demo.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Product {
	
	private int id;
	private String name;
	private float price;
	
	public Product(int id, String name, float price) {
		this.id=id;
		this.name=name;
		this.price=price;
	}
	
	private String getName() {
		return name;
	}
	
	private float getPrice() {
		return price;
	}
	
	@Override
	public String toString() {
		return "ProductName : " +name+ " Price : " +price;
	}
	
	public static void main(String[] args) {
		
		List<Product> productList = Arrays.asList(new Product(121, "Freeze", 45677.90f),
				new Product(122, "LEDTV", 800000f),
				new Product(123, "WashingMachin",300000f),
				new Product(124, "Oven", 430000f));
		
		productList.forEach(s->System.out.println(s));
		
		long count = productList.stream().count();
		System.out.println(count);
		
		List<Product> sortedAccordingToPrice = productList.stream().sorted(Comparator.comparing(Product::getPrice)).toList();
		System.out.println(sortedAccordingToPrice);
		
		List<String> productName = productList.stream().filter(p -> p.getPrice() >= 50000).map(Product::getName).toList();
		System.out.println(productName);
		
		Map<String, Long> productMap= productList.stream().collect(Collectors.groupingBy(Product::getName, Collectors.counting()));
		System.out.println(productMap);
		
		List<Integer> integerList = Arrays.asList(45, 67, 23, 18, 89, 31, 6, 33);
		List<Integer> evenNumberList = integerList.stream().filter(i -> i%2 == 0).toList();
		System.out.println(evenNumberList);		
		
		List<Integer> addTwoInEachNumber = integerList.stream().map(j -> j+2).toList();
		System.out.println(addTwoInEachNumber);
		
		List<Integer> markList = Arrays.asList(45, 67, 23, 18, 89, 31, 6, 33);
		List<Integer> passList = markList.stream().map(mark -> mark < 33 ? Math.min(mark+5, 33) : mark).filter(m -> m >= 33).collect(Collectors.toList());
		System.out.println(passList);
		
		List<Integer> failList = markList.stream().filter(f -> f < 33).collect(Collectors.toList());
		System.out.println(failList);
		
		List<Integer> sortedMarks = markList.stream().sorted().collect(Collectors.toList());
		List<Integer> sortedMarks1 = markList.stream().sorted((i1,i2)->i1.compareTo(i2)).toList();
				System.out.println(sortedMarks1);		
				
		List<Integer> sortedDescOrder = markList.stream().sorted((e1,e2)->-e1.compareTo(e2)).collect(Collectors.toList());
		System.out.println(sortedDescOrder);
		
		List<Integer>valueList = Arrays.asList(45, 67, 23, 18, 89, 31, 6, 33);
		Integer minValue = valueList.stream().min((q1,q2)->q1.compareTo(q2)).orElse(-1);
		System.out.println(minValue);
		
		
		Integer maxValue = valueList.stream().max((r1,r2)->r1.compareTo(r2)).orElse(-1);
		System.out.println(maxValue);
		
		Integer intArr[] = valueList.stream().toArray(Integer[]::new);
		Stream.of(intArr).forEach(System.out::println);
		
		System.out.println("-------print values using Stream only");
		Stream<Integer> s = Stream.of(9,99,999,9999,99999);
		s.forEach(System.out::println);
		
		Integer[] arr1 = {1,8,5,9,3,1,5,7};
		Stream.of(arr1).forEach(System.out::println);
		
		/**
		 * Program to get sum of values which are greater than 30
		 */
		 int sum = valueList.stream()
                 .filter(w -> w>30)
                 .mapToInt(w -> w)
                 .sum();
		 System.out.println("Get sum of values greater than 30: "+sum);
		 
		 List<Integer> eNumber = Arrays.asList(1,2,3,4,5);
		 boolean isEven = eNumber.stream().anyMatch(t-> t%2==0);
		 System.out.println(isEven);
		 
		 boolean greaterNumber = eNumber.stream().allMatch(y -> y < 6);
		 System.out.println(greaterNumber);
		 
		 List<String> findFirstList = Arrays.asList("BDO ","India ","LLP");
		 String firstString = findFirstList.stream().findFirst().orElse("no value");
		 System.out.println(firstString);
	}

}
