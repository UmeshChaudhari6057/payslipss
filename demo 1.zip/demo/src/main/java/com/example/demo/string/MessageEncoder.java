package com.example.demo.string;

public class MessageEncoder {
	public static String encodeMessage(String message) {
		int length = message.length();
		StringBuilder encoded = new StringBuilder();

		for (int i = 0; i < length; i++) {
			char ch = message.charAt(i);
			int transformedAscii = (int) ch - length;
			encoded.append((char) transformedAscii);
		}

		return encoded.toString();
	}
}
