package com.example.demo.employee;

public class Employee {

	private String name;
	private String department;
	private String location;
	private double salary;
	private int experience;

	public Employee() {
	}

	public Employee(String name, String department, String location, double salary) {
		this.name = name;
		this.department = department;
		this.location = location;
		this.salary = salary;
	}

	// Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	@Override
	public String toString() {
		return name + ":" + department + ":" + location + ":" + salary;
	}

}
