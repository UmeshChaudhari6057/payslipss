package com.example.demo.util;

public class Session5 {
	public static void main(String[] args) {
		
	}

}
