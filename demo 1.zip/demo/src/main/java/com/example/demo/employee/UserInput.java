package com.example.demo.employee;

import java.util.*;
import java.util.stream.*;

public class UserInput {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		EmployeeUtility utility = new EmployeeUtility();
		List<Employee> employeeList = new ArrayList<>();

		// Step 1: Get total number of employees
		System.out.println("Enter the total number of employees needed to add in the list");
		int totalEmployees = Integer.parseInt(scanner.nextLine());

		// Step 2: Get employee details
		System.out.println("Enter the employee details");
		for (int i = 0; i < totalEmployees; i++) {
			String[] details = scanner.nextLine().split(":");
			String name = details[0];
			String department = details[1];
			String location = details[2];
			double salary = Double.parseDouble(details[3]);

			Employee emp = new Employee(name, department, location, salary);
			employeeList.add(emp);
		}

		// Step 3: Filter by department
		System.out.println("\nEnter the department");
		String departmentInput = scanner.nextLine();
		Stream<Employee> deptResult = utility.getEmployeesByDepartment(employeeList.stream(), departmentInput);
		List<Employee> deptList = deptResult.collect(Collectors.toList());

		if (deptList.isEmpty()) {
			System.out.println("No employees found for the given department");
		} else {
			deptList.forEach(e -> System.out.println(e.toString()));
		}

		// Step 4: Filter by location
		System.out.println("\nEnter the location");
		String locationInput = scanner.nextLine();
		List<Employee> locationList = utility.getEmployeesByLocation(employeeList.stream(), locationInput);

		if (locationList.isEmpty()) {
			System.out.println("No employees found for the given location");
		} else {
			locationList.forEach(e -> System.out.println(e.toString()));
		}

		// Step 5: Filter by salary range
		System.out.println("\nEnter the salary range (min max)");
		String[] salaryRange = scanner.nextLine().split(" ");
		double minSalary = Double.parseDouble(salaryRange[0]);
		double maxSalary = Double.parseDouble(salaryRange[1]);

		Stream<Employee> salaryResult = utility.getEmployeesInSalaryRange(employeeList, minSalary, maxSalary);
		List<Employee> salaryList = salaryResult.collect(Collectors.toList());

		if (salaryList.isEmpty()) {
			System.out.println("No employees found within the given salary range");
		} else {
			salaryList.forEach(e -> System.out.println(e.toString()));
		}

		scanner.close();
	}

}
