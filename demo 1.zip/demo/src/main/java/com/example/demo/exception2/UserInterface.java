package com.example.demo.exception2;

import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String username = "";
		try {
			System.out.println("Enter Username:");
			username = scanner.nextLine();

			System.out.println("Enter Password:");
			String password = scanner.nextLine();

			AccountManager.validateCredentials(username, password);
			System.out.println("\nLogin Successful!");

			int option;
			do {
				System.out.println("\nChoose an Option:");
				System.out.println("1. Deposit");
				System.out.println("2. Withdraw");
				System.out.println("3. Check Balance");
				System.out.println("4. Exit");
				System.out.print("\nEnter Option: ");
				option = Integer.parseInt(scanner.nextLine());

				switch (option) {
				case 1:
					System.out.println("Enter Amount to Deposit:");
					double depositAmount = Double.parseDouble(scanner.nextLine());
					try {
						AccountManager.deposit(username, depositAmount);
						System.out.printf("Deposit Successful. New Balance: $%.2f%n",
								AccountManager.checkBalance(username));
					} catch (IllegalArgumentException e) {
						System.out.println(e.getMessage());
					}
					break;

				case 2:
					System.out.println("Enter Amount to Withdraw:");
					double withdrawAmount = Double.parseDouble(scanner.nextLine());
					try {
						AccountManager.withdraw(username, withdrawAmount);
						System.out.printf("Withdrawal Successful. New Balance: $%.2f%n",
								AccountManager.checkBalance(username));
					} catch (IllegalArgumentException | InsufficientFundsException e) {
						System.out.println(e.getMessage());
					}
					break;

				case 3:
					System.out.printf("Current Balance: $%.2f%n", AccountManager.checkBalance(username));
					break;

				case 4:
					System.out.println("Logout Successful.");
					break;

				default:
					System.out.println("Invalid option. Please try again.");
				}

			} while (option != 4);

		} catch (InvalidCredentialsException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Invalid input. Please enter numeric values where required.");
		} finally {
			scanner.close();
		}
	}
}
