package com.example.demo.collection3;

public class Content {
	private String text;
	private boolean isImage;

	public Content(String text, boolean isImage) {
		this.text = text;
		this.isImage = isImage;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public boolean isImage() {
		return isImage;
	}

	public void setImage(boolean isImage) {
		this.isImage = isImage;
	}
}
