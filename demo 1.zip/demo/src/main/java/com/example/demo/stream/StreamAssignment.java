package com.example.demo.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAssignment {

	public static void main(String[] args) {
		List<Fruit> fruits = Arrays.asList(new Fruit("Apple", 95, 1, "Red"), new Fruit("Banana", 105, 2, "Yellow"),
				new Fruit("Cherry", 50, 3, "Red"), new Fruit("Date", 70, 4, "Brown"),
				new Fruit("Elderberry", 80, 5, "Purple"));

		List<News> newsList = Arrays.asList(new News(1, "User1", "UserA", "The budget is tight this year."),
				new News(2, "User2", "UserB", "Budget cuts are necessary."),
				new News(3, "User3", "UserA", "We need to discuss the budget."),
				new News(4, "User4", "UserC", "Budget planning is crucial."),
				new News(5, "User5", "UserB", "The budget meeting is scheduled."));

		Trader t1 = new Trader("Trader1", "Pune");
		Trader t2 = new Trader("Trader2", "Mumbai");
		Trader t3 = new Trader("Trader3", "Delhi");
		Trader t4 = new Trader("Trader4", "Pune");
		Trader t5 = new Trader("Trader5", "Indore");

		List<Transaction> transactions = Arrays.asList(new Transaction(t1, 2011, 1000), new Transaction(t2, 2012, 2000),
				new Transaction(t3, 2011, 1500), new Transaction(t4, 2011, 500), new Transaction(t5, 2013, 3000));

		// 1
		System.out.println("1. Low calorie fruits:");
		fruits.stream().filter(f -> f.calories < 100).sorted(Comparator.comparingInt(f -> -f.calories))
				.forEach(System.out::println);

		// 2
		System.out.println("\n2. Color wise fruit names:");
		fruits.stream()
				.collect(Collectors.groupingBy(f -> f.color, Collectors.mapping(f -> f.name, Collectors.toList())))
				.forEach((color, names) -> System.out.println(color + ": " + names));

		// 3
		System.out.println("\n3. Red fruits sorted by price:");
		fruits.stream().filter(f -> f.color.equalsIgnoreCase("Red")).sorted(Comparator.comparingInt(f -> f.price))
				.forEach(System.out::println);

		// 4
		System.out.println("\n4. NewsId with max comments:");
		newsList.stream().collect(Collectors.groupingBy(n -> n.newsId, Collectors.counting())).entrySet().stream()
				.max(Map.Entry.comparingByValue()).ifPresent(System.out::println);

		// 5
		System.out.println("\n5. Count of 'budget' in comments:");
		long budgetCount = newsList.stream().map(n -> n.comment.toLowerCase())
				.flatMap(comment -> Arrays.stream(comment.split(" "))).filter(word -> word.equals("budget")).count();
		System.out.println(budgetCount);

		// 6
		System.out.println("\n6. User with max comments:");
		newsList.stream().collect(Collectors.groupingBy(n -> n.commentByUser, Collectors.counting())).entrySet()
				.stream().max(Map.Entry.comparingByValue()).ifPresent(System.out::println);

		// 7
		System.out.println("\n7. Comments count by user:");
		newsList.stream().collect(Collectors.groupingBy(n -> n.commentByUser, Collectors.counting()))
				.forEach((user, count) -> System.out.println(user + ": " + count));

		// 8
		System.out.println("\n8. Transactions in 2011 sorted by value:");
		transactions.stream().filter(t -> t.year == 2011).sorted(Comparator.comparingInt(t -> t.value))
				.forEach(System.out::println);

		// 9
		System.out.println("\n9. Unique cities:");
		transactions.stream().map(t -> t.trader.city).distinct().forEach(System.out::println);

		// 10
		System.out.println("\n10. Traders from Pune sorted by name:");
		Stream.of(t1, t2, t3, t4, t5).filter(tr -> tr.city.equalsIgnoreCase("Pune"))
				.sorted(Comparator.comparing(tr -> tr.name)).forEach(System.out::println);

		// 11
		System.out.println("\n11. All traders' names sorted alphabetically:");
		String names = Stream.of(t1, t2, t3, t4, t5).map(tr -> tr.name).sorted().collect(Collectors.joining(", "));
		System.out.println(names);

		// 12
		System.out.println("\n12. Any traders in Indore?");
		boolean inIndore = Stream.of(t1, t2, t3, t4, t5).anyMatch(tr -> tr.city.equalsIgnoreCase("Indore"));
		System.out.println(inIndore);

		// 13
		System.out.println("\n13. Transactions from Delhi:");
		transactions.stream().filter(t -> t.trader.city.equalsIgnoreCase("Delhi")).map(t -> t.value)
				.forEach(System.out::println);

		// 14
		System.out.println("\n14. Highest transaction value:");
		transactions.stream().mapToInt(t -> t.value).max().ifPresent(System.out::println);

		// 15
		System.out.println("\n15. Transaction with smallest value:");
		transactions.stream().min(Comparator.comparingInt(t -> t.value)).ifPresent(System.out::println);
	}

}
