package com.example.demo.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtility {

	public static Date convertStringToDate(String dateString, String format) throws ParseException {
		DateFormat df = new SimpleDateFormat(format);
		return df.parse(dateString);
	}

	public static String convertDateToString(String dateString, String format) throws ParseException {
		DateFormat df = new SimpleDateFormat(format);
		Date dDate = df.parse(dateString);
		return df.format(dDate);
	}

	public static String calFinancialYear(String fp) throws ParseException {

		StringBuilder financialYear = new StringBuilder();

		SimpleDateFormat sdf = new SimpleDateFormat("MMyyyy");
		Date date = sdf.parse(fp);

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		Integer month = cal.get(Calendar.MONTH) + 1;
		Integer year = cal.get(Calendar.YEAR);
		cal.clear();

		Calendar cal1 = Calendar.getInstance();
		if(0 <= month.compareTo(4)) {
			cal1.set(Calendar.YEAR, year + 1); //changed in rel 2.21 -- existing bug
			financialYear.append(year).append("-").append(cal1.get(Calendar.YEAR));

		}else if(0 > month.compareTo(4)) {
			cal1.set(Calendar.YEAR, year - 1); //changed in rel 2.21 -- existing bug
			financialYear.append(cal1.get(Calendar.YEAR)).append("-").append(year);
		}

		return financialYear.toString();
	}

	public static Date getYesterdayDate(Date currentDate) {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}

}
