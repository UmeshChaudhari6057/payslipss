package com.example.demo.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

//Example 2
public class Order {

	double price;
	String status;

	public Order(double price, String status) {
		this.price = price;
		this.status = status;
	}

	public double getPrice() {
		return price;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "Order{" + "Price = " + price + ", Status = " + status + " }";
	}

	public static void main(String[] args) {
		List<Order> orders = new ArrayList<>();
		orders.add(new Order(12000.0, "Accepted"));
		orders.add(new Order(8000.0, "Completed"));
		orders.add(new Order(15000.0, "Pending"));
		orders.add(new Order(20000.0, "Completed"));
		orders.add(new Order(5000.0, "Rejected"));

		List<Order> filteredOrders = orders.stream().filter(order -> order.getPrice() > 10000
				&& (order.getStatus().equalsIgnoreCase("Accepted") || order.getStatus().equalsIgnoreCase("Completed")))
				.collect(Collectors.toList());
		System.out.println(filteredOrders);

		// Example 3
		Supplier<String> uuidSupplier = () -> UUID.randomUUID().toString();
		System.out.println("Generated UUID : " + uuidSupplier.get());

		Consumer<String> printUpperCase = s -> System.out.println("Uppercase : " + s.toUpperCase());
		printUpperCase.accept("Hello World");

		Predicate<String> isEmpty = String::isEmpty;
		System.out.println("Is String Empty ? " + isEmpty.test(""));

		Function<String, Integer> stringLength = String::length;
		System.out.println("Length of function : " + stringLength.apply("Function"));

		// Example 4
		List<String> words = new ArrayList(
				Arrays.asList("Apple", "Banana", "Mango", "Pineapple", "Grapes", "Kiwi", "Pear"));
		words.removeIf(word -> word.length() % 2 != 0);
		System.out.println("Words with even length : " + words);

		// Example 5
		List<String> wordsList = Arrays.asList("Java", "Lambda", "Expresssion", "Stream", "API");
		StringBuilder result = new StringBuilder();
		Consumer<String> collectFisrtLetter = word -> {
			if (word != null && !word.isEmpty()) {
				result.append(word.charAt(0));
			}
		};
		wordsList.forEach(collectFisrtLetter);
		System.out.println("Resulting String : " + result.toString());

		// Example 6
		List<String> wordsList1 = Arrays.asList("Lambda", "Expression", "Assignments");
		UnaryOperator<String> toUpperCase = String::toUpperCase;
		wordsList1.replaceAll(toUpperCase);
		System.out.println("Uppercase words : " + wordsList1);

		// Example 7
		Map<String, String> map = new LinkedHashMap<>();
		map.put("Name", "Alice");
		map.put("City", "New York");
		map.put("Occupation", "Engineer");

		StringBuilder result1 = new StringBuilder();

		for (Map.Entry<String, String> entry : map.entrySet()) {
			result1.append(entry.getKey()).append(" : ").append(entry.getValue()).append(" ");
		}
		System.out.println("Resulting String -> " + result1.toString().trim());
		
		//Example 8
		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,9,8);
		Consumer<Integer> printNumbers = number -> System.out.println("Number : " + number);
		
		Runnable task = () -> numbers.forEach(printNumbers);
		
		Thread thread = new Thread(task);
		thread.start();
		
		try {
			thread.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
