package com.example.demo.exception4;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

public class AppointmentBookingSystem {

	private static final List<String> SPECIALIZATIONS = Arrays.asList("Cardiology", "Dermatology", "Pediatrics");

	public static void validatePatientDetails(int age, String phoneNumber, String insuranceId)
			throws InvalidAppointmentException {

		if (age < 1 || age > 120) {
			throw new InvalidAppointmentException("Invalid age");
		}

		if (!phoneNumber.matches("\\d{10}")) {
			throw new InvalidAppointmentException("Invalid phone number");
		}

		if (!insuranceId.matches("[a-zA-Z0-9]+")) {
			throw new InvalidAppointmentException("Invalid insurance ID");
		}
	}

	public static void validateDoctorAvailability(String doctorSpecialization, LocalDateTime appointmentDateTime)
			throws UnavailableDoctorException {

		if (!SPECIALIZATIONS.contains(doctorSpecialization)) {
			throw new UnavailableDoctorException("Doctor specialization not available");
		}

		if (appointmentDateTime.isBefore(LocalDateTime.now())) {
			throw new UnavailableDoctorException("Doctor not available at specified time");
		}

		int hour = appointmentDateTime.getHour();
		if (hour < 9 || hour > 17) {
			throw new UnavailableDoctorException("Doctor not available at specified time");
		}
	}

	public static void scheduleAppointment(String patientName, String doctorSpecialization,
			LocalDateTime appointmentDateTime) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d'th' MMMM yyyy");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("h:mm a");

		String formattedDate = appointmentDateTime.format(dateFormatter);
		String formattedTime = appointmentDateTime.format(timeFormatter);

		System.out.println("Appointment scheduled successfully with Dr. Smith (" + doctorSpecialization + ") on "
				+ formattedDate + " at " + formattedTime + ".");
	}
}
