package com.example.demo.exception1;

public class HealthDataProcessor {

	public static boolean validatePatientDetails(int age, String gender, double height, double weight,
			int bloodPressure, double cholesterol) throws InvalidHealthDataException {

		if (age < 18 || age > 100) {
			throw new InvalidHealthDataException("Invalid age");
		}

		if (!gender.equals("Male") && !gender.equals("Female")) {
			throw new InvalidHealthDataException("Invalid gender");
		}

		if (height <= 0) {
			throw new InvalidHealthDataException("Invalid height");
		}

		if (weight <= 0) {
			throw new InvalidHealthDataException("Invalid weight");
		}

		if (bloodPressure < 60 || bloodPressure > 220) {
			throw new InvalidHealthDataException("Invalid blood pressure");
		}

		if (cholesterol < 0) {
			throw new InvalidHealthDataException("Invalid cholesterol");
		}

		return true;
	}

	public static double calculateInsurancePremium(double height, double weight, int age, int bloodPressure,
			double cholesterol) {
		double bmi = weight / (height * height);

		boolean veryHigh = bmi > 35 || bloodPressure > 180 || cholesterol > 7.0;
		boolean high = bmi > 30 || bloodPressure > 140 || cholesterol > 6.0;

		if (veryHigh) {
			return 1500.0;
		} else if (high) {
			return 1000.0;
		} else {
			return 750.0;
		}
	}
}
