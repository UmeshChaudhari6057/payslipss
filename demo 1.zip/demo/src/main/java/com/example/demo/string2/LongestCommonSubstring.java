package com.example.demo.string2;

import java.util.Scanner;

public class LongestCommonSubstring {

	// Validate input: only letters, digits, and spaces allowed
	public static boolean isValid(String s) {
		return s.matches("[a-zA-Z0-9 ]+");
	}

	// Find longest common substring using dynamic programming
	public static String findLCS(String s1, String s2) {
		int maxLen = 0;
		int endIndex = 0;
		int[][] dp = new int[s1.length() + 1][s2.length() + 1];

		for (int i = 1; i <= s1.length(); i++) {
			for (int j = 1; j <= s2.length(); j++) {
				if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
					dp[i][j] = dp[i - 1][j - 1] + 1;
					if (dp[i][j] > maxLen) {
						maxLen = dp[i][j];
						endIndex = i;
					}
				}
			}
		}

		return s1.substring(endIndex - maxLen, endIndex);
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		String s1 = scanner.nextLine();
		String s2 = scanner.nextLine();

		if (!isValid(s1) || !isValid(s2)) {
			System.out.println("Invalid Input");
			return;
		}

		String lcs = findLCS(s1, s2);

		System.out.println("Length: " + lcs.length());
		System.out.println("Uppercase: " + lcs.toUpperCase());
		System.out.println("Lowercase: " + lcs.toLowerCase());

		scanner.close();
	}
}
