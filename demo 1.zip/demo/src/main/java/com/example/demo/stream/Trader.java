package com.example.demo.stream;

public class Trader {

	String name;
	String city;

	Trader(String name, String city) {
		this.name = name;
		this.city = city;
	}

	public String toString() {
		return name + " from " + city;
	}

}
