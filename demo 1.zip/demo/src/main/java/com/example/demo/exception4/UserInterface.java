package com.example.demo.exception4;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.println("Enter patient name:");
			String name = scanner.nextLine();

			System.out.println("Enter age:");
			int age = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter phone number:");
			String phone = scanner.nextLine();

			System.out.println("Enter insurance ID:");
			String insuranceId = scanner.nextLine();

			AppointmentBookingSystem.validatePatientDetails(age, phone, insuranceId);

			System.out.println("Enter doctor specialization:");
			String specialization = scanner.nextLine();

			System.out.println("Enter appointment date/time (yyyy-MM-dd HH:mm):");
			String dateTimeInput = scanner.nextLine();

			LocalDateTime appointmentDateTime;
			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
				appointmentDateTime = LocalDateTime.parse(dateTimeInput, formatter);
			} catch (DateTimeParseException e) {
				throw new UnavailableDoctorException("Doctor not available at specified time");
			}

			AppointmentBookingSystem.validateDoctorAvailability(specialization, appointmentDateTime);
			AppointmentBookingSystem.scheduleAppointment(name, specialization, appointmentDateTime);

		} catch (InvalidAppointmentException | UnavailableDoctorException e) {
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Invalid number format.");
		} finally {
			scanner.close();
		}
	}
}
