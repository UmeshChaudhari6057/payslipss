package com.example.demo.exception1;

public class InvalidHealthDataException extends Exception {
	public InvalidHealthDataException(String message) {
		super(message);
	}
}
