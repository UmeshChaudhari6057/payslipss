package com.example.demo.util;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Client {

	private int id;
	private String firstName;
	private String lastName;
	private String gender;
	private int age;
	private LocalDate dob;
	private String dept;

	public Client(int id, String firstName, String lastName, String gender, LocalDate dob, String dept, int age) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
		this.dept = dept;
		this.age = age;	
	}

	public String getFirstName() {
		return firstName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public String getDept() {
		return dept;
	}

	public Integer getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public String toString() {
		return "Client { firstName : " + firstName + " dob : " + dob + " }";
	}

	public static void main(String[] args) {

		List<Client> clientList = Arrays.asList(
				new Client(1, "Sayli", "Dukre", "Female", LocalDate.of(1996, 02, 19), "IT", 28),
				new Client(2, "Komal", "Tite", "Female", LocalDate.of(1993, 12, 12), "Dev", 40),
				new Client(3, "Kiya", "Belly", "Female", LocalDate.of(1999, 12, 29), "Admin", 25),
				new Client(4, "Diya", "FiLe", "Female", LocalDate.of(1991, 2, 10), "Dev", 26),
				new Client(5, "John", "Jerry", "Male", LocalDate.of(1992, 9, 10), "Admin", 21),
				new Client(6, "Sayli", "Deul", "Female", LocalDate.of(1996, 2, 10), "IT", 34),
				new Client(7, "Alice", "Perry", "Male", LocalDate.of(1999, 3, 11), "Dev", 36),
				new Client(8, "Ved", "Deul", "Male", LocalDate.of(1994, 2, 10), "Dev", 40),
				new Client(9, "Rina", "Nane", "Female", LocalDate.of(1992, 2, 10), "Dev", 42));

		//List of all client
		clientList.forEach(System.out::println);		
		clientList.forEach(System.out::print);
		
		List<Client> clients = clientList.stream().collect(Collectors.toList());
		clientList.stream().collect(Collectors.toList());
		System.out.println(clients);
		
		//count of total clients
		Long count = clientList.stream().count();
		System.out.println(count);
		
		
		//Average age of clients
		Double age = clientList.stream().mapToInt(c->c.getAge()).average().orElse(-1);
		System.out.println(age);
		clientList.stream().mapToInt(emp -> emp.getAge()).average().orElse(-1);
		
		
		//first sort using dob and second sording according to first name get list of client
		List<Client> sortedDob = clientList.stream().sorted(Comparator.comparing(Client::getDob).thenComparing(Client::getFirstName)).collect(Collectors.toList());
		System.out.println(sortedDob);
	
		
		//get count according to gender in key : value format
		Map<String, Long> countAccordingToGender = clientList.stream().collect(Collectors.groupingBy(Client::getGender, Collectors.counting()));
		System.out.println(countAccordingToGender);
		clientList.stream().collect(Collectors.groupingBy(Client::getGender, Collectors.counting()));
		
		//get client names whose dept is dev
		List<String> clientNames = clientList.stream().filter(x -> x.getDept().equalsIgnoreCase("dev")).map(Client::getFirstName).toList();
		System.out.println(clientNames);
		List<String> names = clientList.stream().filter(e->e.getDept().equalsIgnoreCase("Dev")).map(Client::getFirstName).toList();
		
		
		//get list of duplicate employee on basis of firstname and dept
		Map<String, List<Client>> duplicateClient = clientList.stream().collect(Collectors.groupingBy(y->y.getFirstName()+"-"+y.getDept()))
		.entrySet().stream().filter(entry->entry.getValue().size() > 1)
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		duplicateClient.forEach((key,value)->value.forEach(s -> System.out.println(s)));			
		
		//Average age of clients
		Double avgAge = clientList.stream().collect(Collectors.averagingDouble(Client::getAge));	
		System.out.println(avgAge);
	}

}
