package com.example.demo.book;

import java.util.*;

public class UserInput {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		List<Book> bookList = new ArrayList<>();
		LibraryUtility util = new LibraryUtility();

		System.out.println("Enter the number of books to be added:");
		int n = Integer.parseInt(scanner.nextLine());

		System.out.println("\nEnter book details:");
		System.out.println("Book ID, Title, Author, Genre, Price, Availability");

		for (int i = 0; i < n; i++) {
			String[] input = scanner.nextLine().split(",\\s*");
			String bookId = input[0];
			String title = input[1];
			String author = input[2];
			String genre = input[3];
			double price = Double.parseDouble(input[4]);
			boolean available = Boolean.parseBoolean(input[5]);

			bookList.add(new Book(bookId, title, author, genre, price, available));
		}

		// Retrieve by Book ID
		System.out.println("\nEnter the Book ID to retrieve details:");
		String idInput = scanner.nextLine();
		Book bookById = util.retrieveBookDetailsById(bookList.stream(), idInput);
		if (bookById != null) {
			System.out.println("\n" + bookById);
		} else {
			System.out.println("No book found with the given ID.");
		}

		// Retrieve by Genre
		System.out.println("\nEnter the Genre to retrieve details:");
		String genreInput = scanner.nextLine();
		List<Book> booksByGenre = util.retrieveBooksByGenre(bookList.stream(), genreInput);
		if (!booksByGenre.isEmpty()) {
			booksByGenre.forEach(System.out::println);
		} else {
			System.out.println("No books found for the given genre.");
		}

		// Retrieve by Price Range
		System.out.println("\nEnter the minimum and maximum price range to show book IDs:");
		String[] range = scanner.nextLine().split("\\s+");
		double min = Double.parseDouble(range[0]);
		double max = Double.parseDouble(range[1]);

		List<String> bookIdsInRange = util.retrieveBookIdsInPriceRange(bookList.stream(), min, max);
		if (!bookIdsInRange.isEmpty()) {
			System.out.println("\nBook IDs within the price range are:");
			bookIdsInRange.forEach(System.out::println);
		} else {
			System.out.println("No books found within the given price range.");
		}

		scanner.close();
	}

}
