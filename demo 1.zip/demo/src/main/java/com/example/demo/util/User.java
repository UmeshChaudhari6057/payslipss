package com.example.demo.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class User {
	
//	private int id;
//	private String name;
//	
//	public User(int id, String name) {
//		this.id = id;
//		this.name = name;
//	}
//	
//	public static void main(String[] args) {
//		List<User> userList = Arrays.asList(new User(101, "Sam"),
//				new User(102, "Ram"),
//				new User(103, "Pran"));
//		Map<Integer, String> userMap = userList.stream().collect(Collectors.toMap(user->user.id, user->user.name));
//		System.out.println(userMap);
//		
//		List<String> names = Arrays.asList("Red","Yellow","Pink","Blue");
//		Map<Integer, String> nameMap = new HashMap<>();
//		for(int i = 0; i < names.size(); i++) {
//			nameMap.put(i, names.get(i));
//		}
//		System.out.println(nameMap);
//	}
	
	private int id;
	private String name;
	
	public User(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public static void main(String[] args) {
		//List to Map conversion
		List<User> userList = Arrays.asList(new User(101,"Sam"),
				new User(102, "Tom"),
				new User(103, "Rom"));
		Map<Integer, String> userMap = userList.stream().collect(Collectors.toMap(user->user.id, user->user.name));
		System.out.println(userMap);
		
		List<String> list = Arrays.asList("red","yellow","pink","blue");
		Map<Integer, String> map = new HashMap<>();
		for(int i = 0; i < list.size(); i++) {
			map.put(i, list.get(i));					
		}
		System.out.println(map);
		
		
		//List to Set conversion
		List<String> colours = Arrays.asList("Black","White","Gray","Purple");
		Set<String> coloursSet = colours.stream().collect(Collectors.toSet());
		System.out.println(coloursSet);
		
		//Set to List conversion
		Set<String> flowerSet = new HashSet<>(Arrays.asList("Rose","Lotus","Mogra","Lilly"));
		List<String> flowerList = flowerSet.stream().collect(Collectors.toList());
		System.out.println(flowerList);
	}

}
