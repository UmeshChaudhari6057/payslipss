package com.example.demo.collection4;

import java.util.ArrayList;
import java.util.Collections;

public class CaffeineSurvey {
	private ArrayList<Caffeine> coffeeList;

	public CaffeineSurvey() {
		this.coffeeList = new ArrayList<>();
	}

	public ArrayList<Caffeine> getCoffeeList() {
		return coffeeList;
	}

	public void setCoffeeList(ArrayList<Caffeine> coffeeList) {
		this.coffeeList = coffeeList;
	}

	public ArrayList<Caffeine> sortByBrandName() {
		ArrayList<Caffeine> sortedList = new ArrayList<>(coffeeList);
		Collections.sort(sortedList, new Sorting());
		return sortedList;
	}

	public double getAvgPercentage() {
		if (coffeeList.isEmpty())
			return 0.0;
		double total = 0;
		for (Caffeine c : coffeeList) {
			total += c.getCaffeinePercentage();
		}
		return total / coffeeList.size();
	}
}
