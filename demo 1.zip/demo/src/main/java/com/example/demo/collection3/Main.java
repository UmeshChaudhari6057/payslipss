package com.example.demo.collection3;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Initialize total area for the webpage
		System.out.print("Enter total area of the webpage: ");
		int totalAreaValue = Integer.parseInt(scanner.nextLine());
		Size totalArea = new Size(totalAreaValue);
		WebPage webPage = new WebPage(totalArea);

		System.out.print("Enter number of content blocks to add: ");
		int n = Integer.parseInt(scanner.nextLine());

		for (int i = 0; i < n; i++) {
			System.out.println("\n--- Content Block " + (i + 1) + " ---");

			System.out.print("Enter content text: ");
			String text = scanner.nextLine();

			System.out.print("Is this content an image? (true/false): ");
			boolean isImage = Boolean.parseBoolean(scanner.nextLine());

			System.out.print("Enter area required for this content: ");
			int area = Integer.parseInt(scanner.nextLine());

			Content content = new Content(text, isImage);
			Size size = new Size(area);

			String result = webPage.addPage(size, content);
			System.out.println(result);
		}

		scanner.close();
	}
}
