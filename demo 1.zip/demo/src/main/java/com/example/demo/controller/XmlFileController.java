package com.example.demo.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/api")
public class XmlFileController {

    @GetMapping("/download-xml")
    public ResponseEntity<InputStreamResource> downloadXml() throws IOException {
        // Assuming the XML file is in src/main/resources/files/sample.xml
        ClassPathResource xmlFile = new ClassPathResource("sample.xml");

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=sample.xml")
                .contentType(MediaType.APPLICATION_XML)
                .body(new InputStreamResource(xmlFile.getInputStream()));
    }
}

