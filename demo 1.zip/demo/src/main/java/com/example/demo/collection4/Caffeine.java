package com.example.demo.collection4;

public class Caffeine {
	private String coffeeBrand;
	private float caffeinePercentage;

	public Caffeine(String coffeeBrand, float caffeinePercentage) {
		this.coffeeBrand = coffeeBrand;
		this.caffeinePercentage = caffeinePercentage;
	}

	public String getCoffeeBrand() {
		return coffeeBrand;
	}

	public void setCoffeeBrand(String coffeeBrand) {
		this.coffeeBrand = coffeeBrand;
	}

	public float getCaffeinePercentage() {
		return caffeinePercentage;
	}

	public void setCaffeinePercentage(float caffeinePercentage) {
		this.caffeinePercentage = caffeinePercentage;
	}
}
