package com.example.demo.util;

import java.util.*;
import java.util.stream.*;

public class BookUtility {

	public BookUtility() {
	}

	Map<String, List<Book>> retrieveBooksGroupedByGenre(Stream<Book> books) {
		return books.collect(Collectors.groupingBy(Book::getGenre));
	}

	// 2. Get authors and prices by title
	public Map<String, Double> getAuthorsAndPricesByTitle(Stream<Book> books, String title) {

		return books.filter(book -> book.getTitle().equals(title))
				.collect(Collectors.toMap(Book::getAuthor, Book::getPrice, (existing, replacement) -> existing));

	}

	// 3. Generate summary report
	public Stream<String> generateSummaryReport(List<Book> books) {
		long totalBooks = books.size();
		double totalPrice = books.stream().mapToDouble(Book::getPrice).sum();
		int totalQuantity = books.stream().mapToInt(Book::getQuantity).sum();

		return Stream.of("Total books: " + totalBooks, "Total price: " + String.format("%.2f", totalPrice),
				"Total quantity: " + totalQuantity);
	}
}
