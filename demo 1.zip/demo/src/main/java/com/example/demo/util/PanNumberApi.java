package com.example.demo.util;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PanNumberApi{
		
		@GetMapping("/extractnumbers")
		public String getNumbers(@RequestParam String pan){
			if(pan == null || pan.isEmpty()){
				return "Invalid PAN Number";
			}
			return pan.replaceAll("[^0-9]","");//pan.replaceAll("[^0-9]","")
		}

}

/// above code example is suppose my pan is CFBPD5047J then I want to print only number means 5047 is my output






