package com.example.demo.util;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DuplicateEmployee {

	private int id;
	private String name;

	// Constructor
	public DuplicateEmployee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	// Getters
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Employee{id=" + id + ", name='" + name + "'}";
	}

	public static void main(String[] args) {

		List<DuplicateEmployee> employees = Arrays.asList(new DuplicateEmployee(1, "Alice"),
				new DuplicateEmployee(2, "Bob"), new DuplicateEmployee(3, "Alice"), new DuplicateEmployee(4, "David"),
				new DuplicateEmployee(1, "Alice"));

		// Find duplicates based on ID
		Map<Integer, Long> idCountMap = employees.stream()
				.collect(Collectors.groupingBy(DuplicateEmployee::getId, Collectors.counting()));

		List<DuplicateEmployee> duplicateEmployeesById = employees.stream().filter(e -> idCountMap.get(e.getId()) > 1)
				.distinct().collect(Collectors.toList());		

		
		System.out.println("Duplicate Employees by ID: " + duplicateEmployeesById);

		// Find duplicates based on Name
		Map<String, Long> nameCountMap = employees.stream()
				.collect(Collectors.groupingBy(DuplicateEmployee::getName, Collectors.counting()));

		List<DuplicateEmployee> duplicateEmployeesByName = employees.stream()
				.filter(e -> nameCountMap.get(e.getName()) > 1).distinct() // To remove exact duplicates
				.collect(Collectors.toList());

		System.out.println("Duplicate Employees by Name: " + duplicateEmployeesByName);
		
		
		
		
		
		
		
		
		
		

	}

}
