package com.example.demo.collection1;

import java.util.ArrayList;
import java.util.List;

public class AccountManager {
	private List<User> userList;

	// Default constructor
	public AccountManager() {
		this.userList = new ArrayList<>();
	}

	// Getter and Setter
	public List<User> getUserList() {
		return userList;
	}

	void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public boolean registerUser(String username, String password, String email) {
		for (User user : userList) {
			if (user.getUsername().equalsIgnoreCase(username) || user.getEmail().equalsIgnoreCase(email)) {
				return false;
			}
		}
		userList.add(new User(username, password, email));
		return true;
	}

	public User login(String username, String password) {
		for (User user : userList) {
			if (user.getUsername().equalsIgnoreCase(username) && user.getPassword().equals(password)) {
				return user;
			}
		}
		return null;
	}

	public boolean resetPassword(String username, String newPassword) {
		for (User user : userList) {
			if (user.getUsername().equalsIgnoreCase(username)) {
				user.setPassword(newPassword);
				return true;
			}
		}
		return false;
	}

	public boolean updateEmail(String username, String newEmail) {
		for (User user : userList) {
			if (user.getUsername().equalsIgnoreCase(username)) {
				user.setEmail(newEmail);
				return true;
			}
		}
		return false;
	}

	public User getUserByUsername(String username) {
		for (User user : userList) {
			if (user.getUsername().equalsIgnoreCase(username)) {
				return user;
			}
		}
		return null;
	}

	public boolean deleteUser(String username) {
		return userList.removeIf(user -> user.getUsername().equalsIgnoreCase(username));
	}
}
