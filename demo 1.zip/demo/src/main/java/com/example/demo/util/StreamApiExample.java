package com.example.demo.util;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class StreamApiExample {		
		//Example 1
	    public static void main(String[] args) {
	        List<Book> bookList = Arrays.asList(
	            new Book("Java Programming", "Computer Science", "John Doe", 10, 45.99),
	            new Book("Python Basics", "Computer Science", "Jane Smith", 8, 39.95),
	            new Book("Data Structures", "Computer Science", "John Doe", 5, 55.50)
	        );

	        BookUtility bookUtility = new BookUtility();

	        // Group by genre
	        Map<String, List<Book>> grouped = bookUtility.retrieveBooksGroupedByGenre(bookList.stream());
	        grouped.forEach((genre, books) -> {
	            System.out.println(genre);
	            books.forEach(System.out::println);
	        });

	        // Get authors and prices by title
	        Map<String, Double> authorsAndPrices = bookUtility.getAuthorsAndPricesByTitle(bookList.stream(), "Python Basics");
	        authorsAndPrices.forEach((author, price) -> System.out.println(author + " " + price));

	        // Summary report
	        bookUtility.generateSummaryReport(bookList).forEach(System.out::println);
	    }
	}



