package com.example.demo.exception2;

import java.util.HashMap;
import java.util.Map;

public class AccountManager {
	private static final double MAX_DEPOSIT_LIMIT = 10000.0;
	private static Map<String, String> credentials = new HashMap<>();
	private static Map<String, Double> accounts = new HashMap<>();

	static {
		// Sample users
		credentials.put("john_doe", "Password123!");
		accounts.put("john_doe", 1000.0);

		credentials.put("user123", "Pass456!");
		accounts.put("user123", 0.0);
	}

	public static void validateCredentials(String username, String password) throws InvalidCredentialsException {
		if (!username.matches("^[a-zA-Z0-9_]{6,}$")) {
			throw new InvalidCredentialsException("Invalid username format.");
		}

		if (!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
			throw new InvalidCredentialsException("Invalid password format.");
		}

		if (!credentials.containsKey(username) || !credentials.get(username).equals(password)) {
			throw new InvalidCredentialsException("Incorrect username or password.");
		}
	}

	public static void deposit(String username, double amount) throws IllegalArgumentException {
		if (amount <= 0) {
			throw new IllegalArgumentException("Invalid amount. Please enter a positive number.");
		}
		if (amount > MAX_DEPOSIT_LIMIT) {
			throw new IllegalArgumentException(
					"Deposit amount exceeds maximum limit of $10,000. Please enter a smaller amount.");
		}
		accounts.put(username, accounts.get(username) + amount);
	}

	public static void withdraw(String username, double amount) throws InsufficientFundsException {
		if (amount <= 0) {
			throw new IllegalArgumentException("Invalid amount. Please enter a positive number.");
		}
		double balance = accounts.get(username);
		if (amount > balance) {
			throw new InsufficientFundsException("Insufficient Funds. Current Balance: $" + balance);
		}
		accounts.put(username, balance - amount);
	}

	public static double checkBalance(String username) {
		return accounts.get(username);
	}
}
