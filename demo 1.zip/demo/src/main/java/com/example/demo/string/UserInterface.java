package com.example.demo.string;

import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter message:");
		String input = scanner.nextLine();

		if (input.length() <= 4) {
			System.out.println("The string " + input + " has minimum length");
			return;
		}

		if (input.contains(" ")) {
			System.out.println("The string " + input + " should not contain space");
			return;
		}

		String encodedMessage = MessageEncoder.encodeMessage(input);
		System.out.println(encodedMessage);
	}
}
