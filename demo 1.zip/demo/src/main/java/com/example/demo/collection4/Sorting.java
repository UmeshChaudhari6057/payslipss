package com.example.demo.collection4;

import java.util.Comparator;

public class Sorting implements Comparator<Caffeine> {
	@Override
	public int compare(Caffeine o1, Caffeine o2) {
		return o1.getCoffeeBrand().compareToIgnoreCase(o2.getCoffeeBrand());
	}
}
