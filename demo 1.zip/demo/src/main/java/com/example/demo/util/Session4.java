package com.example.demo.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Session4 {

	public static void main(String[] args) {
	   
		String input = "121"; // Change this to any string or number
        boolean isPalindrome = true; 
        // Convert the input into a character array manually
        char[] characters = input.toCharArray();      
        // Check for palindrome using two-pointer logic
        int start = 0;
        int end = input.length() - 1;
 
        while (start < end) {
            if (characters[start] != characters[end]) {
                isPalindrome = false;
                break;
            }
            start++;
            end--;
        }
        // Output result
        if (isPalindrome) {
            System.out.println(input + " is a palindrome.");
        } else {
            System.out.println(input + " is not a palindrome.");
        }
		
        
				
		//Create a map and convert it into the list
		Map<String, Integer> map = new HashMap<>();
		map.put("Apple", 40);
		map.put("banana", 25);
		map.put("Chikoo", 30);
		map.put("Mango", 70);
		
		//Print above map
		Map<String, Integer> fruitMap = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue,newValue)->oldValue, LinkedHashMap::new));
		System.out.println(fruitMap);
		
		//Convert keys to List
		List<String> keyList = new ArrayList<>(map.keySet());
		System.out.println(keyList);
		
		//Convert values to List
		List<Integer> valueList = new ArrayList<>(map.values());
		System.out.println(valueList);
		
		//above map convert it into the list
		List<Map.Entry<String, Integer>> entryList = new ArrayList<>(map.entrySet());
		for(Map.Entry<String, Integer> entry : entryList) {
			System.out.println(entry.getKey()+ ":" + entry.getValue());
		}

		String input1 = "This is my project This is your project";
		String[] words = input1.split(" ");
		Map<String, Integer> map1 = new HashMap<>();
		for(String word : words) {
			if(map1.containsKey(word)) {
				map1.put(word, map1.get(word)+1);
			}else {
				map1.put(word, 1);
			}
			
		}
		System.out.println(map1);
		
		String input2 = "sayalee";
		char[] chars = input2.toCharArray();
		for(int i = 0; i < chars.length; i++) {
			char c = chars[i];
			if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
				System.out.println(c);
				
			}
		}
		
		List<String> list1 = Arrays.asList("blue", "black","red","pink");
		Map<Integer, String> map2 = new HashMap<>();
		for(int i = 0; i < list1.size(); i++) {
			map2.put(i, list1.get(i));
		}
		System.out.println(map2);
		
		//check strings are anagram or not using inbuild function
		
		String input3 = "listen";
		String input4 = "silent";
		input3 = input3.replaceAll("\\s", "").toLowerCase();
		input4 = input4.replaceAll("\\s", "").toLowerCase();

		char[] array1 = input3.toCharArray();
		char[] array2 = input4.toCharArray();

		if (input3.length() != input4.length()) {
			System.out.println("Not Anagram String");
			return;
		} else {
			Arrays.sort(array1);
			Arrays.sort(array2);

			System.out.println(Arrays.equals(array1, array2));
		}
		
		//check strings are anagram or not without using inbuild function
		String str1 = "Listen";
		String str2 = "Silent";
		boolean ana = true;
		str1 = str1.replaceAll("\\s", "").toLowerCase();
		str2 = str2.replaceAll("\\s", "").toLowerCase();
		
		if(str1.length() != str2.length()) {
			System.out.println("Not Anagrams");
			return;
		}
		int[] charCountArr = new int[26];
		for(int i = 0; i < str1.length(); i++) {
			charCountArr[str1.charAt(i) - 'a']++;
		}
		for(int i = 0; i < str2.length(); i++) {
			charCountArr[str2.charAt(i) - 'a']--;
		}
		for(int i : charCountArr) {
			if( i != 0) {
				ana = false;
			}
		}
		System.out.println(ana);
		
		String input6 = "Sayalee";
		
		Map<Character, Integer> map3 = new HashMap<>();
		for(int i = 0 ; i < input6.length(); i++) {
			char ch = input6.charAt(i);
			if(map3.containsKey(ch)) {
				map3.put(ch, map.get(ch) + 1);
			}else {
				map3.put(ch, 1);
			}
		}
		System.out.println(map3);
 	}
}
