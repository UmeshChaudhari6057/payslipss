package com.example.demo.util;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Employee {

	private int id;
	private String firstName;
	private String lastName;
	private String gender;
	private LocalDate dob;
	private String dept;
	private Integer age;
	private Long salary;

	public Employee(int id, String firstName, String lastName, String gender, LocalDate dob, String dept, Integer age, Long salary) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
		this.dept = dept;
		this.age=age;
		this.salary=salary;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getGender() {
		return gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public String getDept() {
		return dept;
	}
	
	public Integer getAge() {
		return age;
	}
	
	public Long getSalary() {
		return salary;
	}

	public String toString() {
		return "{Employee : FirstName : " + firstName + " Dob : " + dob + "}";
	}

	public static void main(String[] args) {
		List<Employee> empList = Arrays.asList(
				new Employee(1, "Sayli", "Deul", "Female", LocalDate.of(1996, 2, 10), "Dev", 30, 20000L),
				new Employee(2, "Komal", "Tite", "Female", LocalDate.of(1993, 12, 12), "Dev", 40, 90000L),
				new Employee(3, "Kiya", "Belly", "Female", LocalDate.of(1999, 12, 29), "Admin", 25, 10000L),
				new Employee(4, "Diya", "FiLe", "Female", LocalDate.of(1991, 2, 10), "Dev", 26, 40000L),
				new Employee(5, "John", "Jerry", "Male", LocalDate.of(1992, 9, 10), "Admin", 21, 1000L),
				new Employee(6, "Sayli", "Deul", "Female", LocalDate.of(1996, 2, 10), "Dev", 34, 77000L),
				new Employee(7, "Alice", "Perry", "Male", LocalDate.of(1999, 3, 11), "Dev", 36, 9000L),
				new Employee(8, "Ved", "Deul", "Male", LocalDate.of(1994, 2, 10), "Dev", 40, 80000L),
				new Employee(9, "Rina", "Nane", "Female", LocalDate.of(1992, 2, 10), "Dev", 42, 60000L));

		empList.forEach(s -> System.out.println(s));
		Long count = empList.stream().count();
		System.out.println("Count of Total Employee : " + count);

		// Duplicate Employee
		Map<String, List<Employee>> duplicateEmp = empList.stream()
				.collect(Collectors.groupingBy(emp -> emp.getFirstName() + "-" + emp.getDept())).entrySet().stream()
				.filter(entry -> entry.getValue().size() > 1)
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		duplicateEmp.forEach((key, emp) -> emp.forEach(emp1 -> System.out.println(emp1)));

		// Count According to gender
		Map<String, Long> genderCount = empList.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
		System.out.println("Gender Count : " + genderCount);

		// Sorting using dob and firstName
		List<Employee> sortedList = empList.stream()
				.sorted(Comparator.comparing(Employee::getDob).thenComparing(Employee::getFirstName)).toList();
		System.out.println("Sorted List : " + sortedList);
		
		
		//Get Only Admin dept employee
		List<Employee> adminDeptEmp = empList.stream().filter(emp->emp.getDept().equalsIgnoreCase("Admin")).toList();
		System.out.println("Admin Dept Employees : " +adminDeptEmp);	
		
		
		//get avarage age of employee
		double averageAge = empList.stream().mapToInt(Employee::getAge).average().orElse(0);
		System.out.println("Average age of employees : " +averageAge);
		
		
		//Whose age is greater than 30 list
		List<String> empListAge = empList.stream().filter(emp->emp.getAge() >= 30).map(Employee::getFirstName).toList();
		System.out.println(empListAge);
				
		Map<String, Double> averageAgeOfMaleAndFemale = empList.stream().collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingInt(Employee::getAge)));
		System.out.println(averageAgeOfMaleAndFemale);
		
		Optional<Long> maxSalary = empList.stream().max(Comparator.comparingLong(Employee::getSalary)).map(Employee::getSalary);
		System.out.println(maxSalary);
		
		Long salaray = empList.stream().max(Comparator.comparingLong(Employee::getSalary)).map(Employee::getSalary).orElse(0L);
	}

}
