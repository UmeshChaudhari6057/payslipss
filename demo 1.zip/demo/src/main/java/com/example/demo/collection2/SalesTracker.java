package com.example.demo.collection2;

import java.util.*;

public class SalesTracker {
	private Set<String> salesSet;

	// Default constructor
	public SalesTracker() {
		this.salesSet = new HashSet<>();
	}

	// Getter and Setter
	public Set<String> getSalesSet() {
		return salesSet;
	}

	public void setSalesSet(Set<String> salesSet) {
		this.salesSet = salesSet;
	}

	// Requirement 1: Add sales record
	public void addSalesRecord(String record) {
		salesSet.add(record);
	}

	// Requirement 2: Count unique customers by product
	public int findNumberOfCustomersByProduct(String product) {
		Set<String> customers = new HashSet<>();
		for (String record : salesSet) {
			String[] parts = record.split(":");
			if (parts.length == 2 && parts[1].equalsIgnoreCase(product)) {
				customers.add(parts[0]);
			}
		}
		return customers.isEmpty() ? -1 : customers.size();
	}

	// Requirement 3: Get customers by product
	public List<String> getCustomersByProduct(String product) {
		List<String> customers = new ArrayList<>();
		for (String record : salesSet) {
			String[] parts = record.split(":");
			if (parts.length == 2 && parts[1].equalsIgnoreCase(product)) {
				customers.add(parts[0]);
			}
		}
		return customers;
	}

	// Requirement 4: Get product by customer
	public String getProductByCustomer(String customerName) {
		for (String record : salesSet) {
			String[] parts = record.split(":");
			if (parts.length == 2 && parts[0].equalsIgnoreCase(customerName)) {
				return parts[1];
			}
		}
		return null;
	}
}
