package com.example.demo.util;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Practise {
	public static void main(String[] args) {

		
		
		
	}

}
