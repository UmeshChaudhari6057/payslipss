package com.example.apigateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

	@Bean
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes()

				// User Service
				.route("user-service",
						r -> r.path("/user-service/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:8081"))

				// Restaurant Service
				.route("restaurant-service",
						r -> r.path("/restaurant-service/**").filters(f -> f.stripPrefix(1))
								.uri("http://localhost:8091"))

				// Order Service
				.route("order-service",
						r -> r.path("/order-service/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:8092"))

				// Delivery Service
				.route("delivery-service",
						r -> r.path("/delivery-service/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:8093"))

				// Notification Service
				.route("notification-service",
						r -> r.path("/notification-service/**").filters(f -> f.stripPrefix(1))
								.uri("http://localhost:8094"))

				.build();
	}
}
