package com.example.restaurant_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.restaurantservice.RestaurantServiceApplication;


@SpringBootTest(classes = RestaurantServiceApplication.class)

class RestaurantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
