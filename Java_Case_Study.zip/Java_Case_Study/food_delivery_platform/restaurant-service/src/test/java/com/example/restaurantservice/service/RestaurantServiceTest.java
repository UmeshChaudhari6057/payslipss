package com.example.restaurantservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.restaurantservice.dto.RestaurantDTO;
import com.example.restaurantservice.entity.Restaurant;
import com.example.restaurantservice.exception.ResourceNotFoundException;
import com.example.restaurantservice.repository.RestaurantRepository;

@ExtendWith(MockitoExtension.class)
class RestaurantServiceTestTest {

    @Mock
    private RestaurantRepository restaurantRepository;

    @InjectMocks
    private RestaurantService restaurantService;

    private Restaurant restaurant;
    private RestaurantDTO restaurantDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        restaurant = new Restaurant();
        restaurant.setId(1L);
        restaurant.setName("Test Restaurant");
        restaurant.setAddress("123 Street");
        restaurant.setCuisine("Italian");
        restaurant.setIsAvailable("Yes");

        restaurantDTO = new RestaurantDTO();
        restaurantDTO.setName("Test Restaurant");
        restaurantDTO.setAddress("123 Street");
        restaurantDTO.setCuisine("Italian");
        restaurantDTO.setIsAvailable("Yes");
    }

    @Test
    void testCreateRestaurant() {
        when(restaurantRepository.save(any(Restaurant.class))).thenReturn(restaurant);

        RestaurantDTO result = restaurantService.createRestaurant(restaurantDTO);

        assertEquals("Test Restaurant", result.getName());
        verify(restaurantRepository, times(1)).save(any(Restaurant.class));
    }

    @Test
    void testGetRestaurantById_Found() {
        when(restaurantRepository.findById(1L)).thenReturn(Optional.of(restaurant));

        RestaurantDTO result = restaurantService.getRestaurantById(1L);

        assertEquals("Test Restaurant", result.getName());
    }

    @Test
    void testGetRestaurantById_NotFound() {
        when(restaurantRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> restaurantService.getRestaurantById(1L));
    }

    @Test
    void testGetAllRestaurants() {
        when(restaurantRepository.findAll()).thenReturn(Arrays.asList(restaurant));

        List<RestaurantDTO> result = restaurantService.getAllRestaurants();

        assertEquals(1, result.size());
        assertEquals("Test Restaurant", result.get(0).getName());
    }

    @Test
    void testUpdateRestaurant_Found() {
        when(restaurantRepository.findById(1L)).thenReturn(Optional.of(restaurant));
        when(restaurantRepository.save(any(Restaurant.class))).thenReturn(restaurant);

        RestaurantDTO result = restaurantService.updateRestaurant(1L, restaurantDTO);

        assertEquals("Test Restaurant", result.getName());
    }

    @Test
    void testUpdateRestaurant_NotFound() {
        when(restaurantRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> restaurantService.updateRestaurant(1L, restaurantDTO));
    }

    @Test
    void testDeleteRestaurant_Found() {
        when(restaurantRepository.existsById(1L)).thenReturn(true);

        restaurantService.deleteRestaurant(1L);

        verify(restaurantRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteRestaurant_NotFound() {
        when(restaurantRepository.existsById(1L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> restaurantService.deleteRestaurant(1L));
    }
}

