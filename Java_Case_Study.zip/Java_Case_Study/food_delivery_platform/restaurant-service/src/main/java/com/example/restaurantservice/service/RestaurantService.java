package com.example.restaurantservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.restaurantservice.dto.RestaurantDTO;
import com.example.restaurantservice.entity.Restaurant;
import com.example.restaurantservice.exception.ResourceNotFoundException;
import com.example.restaurantservice.repository.RestaurantRepository;

@Service
public class RestaurantService {

	@Autowired
	private RestaurantRepository restaurantRepository;

	private RestaurantDTO mapToDTO(Restaurant restaurant) {
		RestaurantDTO dto = new RestaurantDTO();		
		dto.setName(restaurant.getName());
		dto.setAddress(restaurant.getAddress());
		dto.setCuisine(restaurant.getCuisine());
		dto.setIsAvailable(restaurant.getIsAvailable());
		return dto;
	}

	private Restaurant mapToEntity(RestaurantDTO dto) {
		Restaurant restaurant = new Restaurant();
		
		restaurant.setName(dto.getName());
		restaurant.setAddress(dto.getAddress());
		restaurant.setCuisine(dto.getCuisine());
		restaurant.setIsAvailable(dto.getIsAvailable());
		return restaurant;
	}

	public RestaurantDTO createRestaurant(RestaurantDTO dto) {
		return mapToDTO(restaurantRepository.save(mapToEntity(dto)));
	}

	public RestaurantDTO getRestaurantById(Long id) {
		return restaurantRepository.findById(id).map(this::mapToDTO)
				.orElseThrow(() -> new ResourceNotFoundException("Restaurant not found with id: " + id));
	}

	public List<RestaurantDTO> getAllRestaurants() {
		return restaurantRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
	}

	public RestaurantDTO updateRestaurant(Long id, RestaurantDTO dto) {
		Restaurant restaurant = restaurantRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Restaurant not found with id: " + id));

		restaurant.setName(dto.getName());
		restaurant.setAddress(dto.getAddress());
		restaurant.setCuisine(dto.getCuisine());
		restaurant.setIsAvailable(dto.getIsAvailable());

		return mapToDTO(restaurantRepository.save(restaurant));
	}

	public void deleteRestaurant(Long id) {
		if (!restaurantRepository.existsById(id)) {
			throw new ResourceNotFoundException("Restaurant not found with id: " + id);
		}
		restaurantRepository.deleteById(id);
	}

}
