package com.example.restaurantservice.service;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final String topic = "order-updates";

    public OrderProducer(KafkaTemplate<String, String> kafkaTemplate) {
    	this.kafkaTemplate = kafkaTemplate;
    }

    public void sendOrderUpdate(String orderId, String status) {
        String message = String.format("Order %s status: %s", orderId, status);
        kafkaTemplate.send(topic, orderId, message);
    }
}
