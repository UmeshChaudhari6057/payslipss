package com.example.restaurantservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.restaurantservice.dto.RestaurantDTO;
import com.example.restaurantservice.service.RestaurantService;


@RestController
@RequestMapping("/api/restaurants")
public class RestaurantController {

	@Autowired
	private RestaurantService restaurantService;

	@PostMapping("/registerRestaurant") 
	public ResponseEntity<RestaurantDTO> create(@RequestBody RestaurantDTO dto) {
		System.out.println("Hi");
		return ResponseEntity.ok(restaurantService.createRestaurant(dto));
	}

	@GetMapping("/{id}")
	public ResponseEntity<RestaurantDTO> getById(@PathVariable Long id) {
		return ResponseEntity.ok(restaurantService.getRestaurantById(id));
	}

	@GetMapping
	public ResponseEntity<List<RestaurantDTO>> getAll() {
		return ResponseEntity.ok(restaurantService.getAllRestaurants());
	}

	@PutMapping("/{id}")
	public ResponseEntity<RestaurantDTO> update(@PathVariable Long id, @RequestBody RestaurantDTO dto) {
		return ResponseEntity.ok(restaurantService.updateRestaurant(id, dto));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		restaurantService.deleteRestaurant(id);
		return ResponseEntity.noContent().build();
	}

}
