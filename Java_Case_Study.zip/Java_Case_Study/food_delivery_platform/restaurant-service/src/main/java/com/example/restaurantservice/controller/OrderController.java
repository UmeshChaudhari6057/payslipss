package com.example.restaurantservice.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.restaurantservice.service.OrderProducer;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderProducer orderProducer;

    public OrderController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping("/update")
    public ResponseEntity<String> updateOrder(@RequestParam String orderId, @RequestParam String status) {
        orderProducer.sendOrderUpdate(orderId, status);
        return ResponseEntity.ok("Order update sent to Kafka.");
    }
}

