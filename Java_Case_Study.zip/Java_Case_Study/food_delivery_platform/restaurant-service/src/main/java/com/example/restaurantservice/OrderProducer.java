package com.example.restaurantservice;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.example.restaurantservice.kafka.KafkaConfig;

public class OrderProducer {
    public static void sendOrder(String orderId, String orderDetails) {
        Producer<String, String> producer = new KafkaProducer<>(KafkaConfig.getProducerProps());
        ProducerRecord<String, String> record = new ProducerRecord<>("order-updates", orderId, orderDetails);

        producer.send(record, (metadata, exception) -> {
            if (exception == null) {
                System.out.println("Order sent: " + orderDetails);
            } else {
                exception.printStackTrace();
            }
        });

        producer.close();
    }
}

