package com.example.restaurantservice;

import java.time.Duration;
import java.util.Collections;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.example.restaurantservice.kafka.KafkaConfig;

public class OrderConsumer {
    public static void main(String[] args) {
        Consumer<String, String> consumer = new KafkaConsumer<>(KafkaConfig.getConsumerProps());
        consumer.subscribe(Collections.singletonList("order-updates"));

        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
            for (ConsumerRecord<String, String> record : records) {
                System.out.println("Received order: " + record.value());
            }
        }
    }
}

