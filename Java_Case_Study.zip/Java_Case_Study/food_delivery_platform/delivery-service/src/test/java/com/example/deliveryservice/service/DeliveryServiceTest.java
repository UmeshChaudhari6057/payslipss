package com.example.deliveryservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.deliveryservice.model.Delivery;

class DeliveryServiceTest {

    private DeliveryService deliveryService;

    @BeforeEach
    void setUp() {
        deliveryService = new DeliveryService();
    }

    @Test
    void testAssignDelivery() {
        String orderId = "ORDER123";
        Delivery delivery = deliveryService.assignDelivery(orderId);

        assertNotNull(delivery);
        assertEquals(orderId, delivery.getOrderId());
        assertEquals("Assigned", delivery.getStatus());
        assertTrue(delivery.getDeliveryPartner().startsWith("Partner-"));
        assertNotNull(delivery.getDeliveryId());
    }

    @Test
    void testUpdateStatus() {
        Delivery delivery = deliveryService.assignDelivery("ORDER456");
        String deliveryId = delivery.getDeliveryId();

        Delivery updated = deliveryService.updateStatus(deliveryId, "Delivered");

        assertNotNull(updated);
        assertEquals("Delivered", updated.getStatus());
    }

    @Test
    void testUpdateStatusForNonExistentDelivery() {
        Delivery updated = deliveryService.updateStatus("NON_EXISTENT_ID", "Delivered");
        assertNull(updated);
    }

    @Test
    void testGetDeliveryByOrderId() {
        String orderId = "ORDER789";
        deliveryService.assignDelivery(orderId);

        Delivery found = deliveryService.getDeliveryByOrderIdAndCustomerId(orderId, 0L);

        assertNotNull(found);
        assertEquals(orderId, found.getOrderId());
    }

    @Test
    void testGetDeliveryByOrderIdNotFound() {
        Delivery found = deliveryService.getDeliveryByOrderIdAndCustomerId("UNKNOWN_ORDER",0L);
        assertNull(found);
    }
}
	
