package com.example.deliveryservice.model;

public class Delivery {
    private String deliveryId;
    private Long customerId;
    private String orderId;
    private String deliveryPartner;
    private String status;
 
    // Constructors, Getters, Setters
    public Delivery() {}
 
    public Delivery(String deliveryId,Long customerId, String orderId, String deliveryPartner, String status) {
        this.deliveryId = deliveryId;
        this.customerId = customerId;
        this.orderId = orderId;
        this.deliveryPartner = deliveryPartner;
        this.status = status;
    }
 
    public String getDeliveryId() { return deliveryId; }
    public void setDeliveryId(String deliveryId) { this.deliveryId = deliveryId; }
    
    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }
 
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
 
    public String getDeliveryPartner() { return deliveryPartner; }
    public void setDeliveryPartner(String deliveryPartner) { this.deliveryPartner = deliveryPartner; }
 
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
