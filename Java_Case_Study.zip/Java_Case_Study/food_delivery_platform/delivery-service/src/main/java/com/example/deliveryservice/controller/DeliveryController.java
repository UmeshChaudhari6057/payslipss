package com.example.deliveryservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.deliveryservice.client.OrderClient;
import com.example.deliveryservice.model.Delivery;
import com.example.deliveryservice.service.DeliveryService;

import reactor.core.publisher.Mono;
 
@RestController
@RequestMapping("/deliveries")
public class DeliveryController {
 
    private final DeliveryService deliveryService;
    private final OrderClient orderClient;
 
    public DeliveryController(DeliveryService deliveryService, OrderClient orderClient) {
        this.deliveryService = deliveryService;
        this.orderClient = orderClient;
    }
 
    @PostMapping("/assign/{orderId}")
    public Delivery assignDelivery(@PathVariable String orderId) {
        return deliveryService.assignDelivery(orderId);
    }
 
    @PutMapping("/{deliveryId}/status/{status}")
    public Delivery updateStatus(@PathVariable String deliveryId, @PathVariable String status) {
        return deliveryService.updateStatus(deliveryId, status);
    }
 
    @GetMapping("/track/{orderId}/{customerId}")
    public Delivery trackDelivery(@PathVariable String orderId, @PathVariable Long customerId) {
        return deliveryService.getDeliveryByOrderIdAndCustomerId(orderId, customerId);
    }
 
    @GetMapping("/order-details/{orderId}")
    public Mono<String> getOrderDetails(@PathVariable String orderId) {
        return orderClient.getOrderDetails(orderId);
    }
}
