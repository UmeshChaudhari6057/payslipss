package com.example.deliveryservice.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.deliveryservice.model.Delivery;
 
@Service
public class DeliveryService {
 
    private final Map<String, Delivery> deliveries = new HashMap<>();
 
    public Delivery assignDelivery(String orderId) {
        String deliveryId = UUID.randomUUID().toString();
        String deliveryPartner = "Partner-" + new Random().nextInt(1000);
 
        Delivery delivery = new Delivery(deliveryId, 0L, orderId, deliveryPartner, "Assigned");
        deliveries.put(deliveryId, delivery);
        return delivery;
    }
 
    public Delivery updateStatus(String deliveryId, String status) {
        Delivery delivery = deliveries.get(deliveryId);
        if (delivery != null) {
            delivery.setStatus(status);
        }
        return delivery;
    } 
   
	public Delivery getDeliveryByOrderIdAndCustomerId(String orderId, Long customerId) {
	    return deliveries.values().stream()
	            .filter(d -> d.getOrderId().equals(orderId) && d.getCustomerId().equals(customerId))
	            .findFirst()
	            .orElse(null);
	}

}
