package com.example.deliveryservice.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@Component
public class OrderClient {

	private final WebClient webClient;

	public OrderClient(WebClient.Builder builder) {
		this.webClient = builder.baseUrl("http://localhost:8082").build(); // Order Service URL
	}

	public Mono<String> getOrderDetails(String orderId) {
		return webClient.get().uri("/api/orders/customer/" + orderId).retrieve().bodyToMono(String.class);
	}
}
