package com.example.orderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = OrderServiceApplication.class)
class OrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
