package com.example.orderservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.orderservice.dto.OrderDTO;
import com.example.orderservice.dto.OrderStatus;
import com.example.orderservice.entity.Order;
import com.example.orderservice.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    @Test
    void testPlaceOrder() {
        OrderDTO dto = new OrderDTO();
        dto.setCustomerId(1L);
        dto.setRestaurantId(2L);
        dto.setItems("Pizza");
        dto.setTotalAmount(500.0);

        Order savedOrder = new Order();
        savedOrder.setId(1L);
        savedOrder.setCustomerId(1L);
        savedOrder.setRestaurantId(2L);
        savedOrder.setItems("Pizza");
        savedOrder.setTotalAmount(500.0);
        savedOrder.setStatus(OrderStatus.PLACED);
        savedOrder.setOrderTime(OffsetDateTime.now());

        Mockito.when(orderRepository.save(Mockito.any(Order.class))).thenReturn(savedOrder);

        OrderDTO result = orderService.placeOrder(dto);

        assertEquals(1L, result.getId());
        assertEquals(OrderStatus.PLACED, result.getStatus());
    }

    @Test
    void testGetOrdersByCustomer() {
        Order order = new Order();
        order.setId(1L);
        order.setCustomerId(1L);
        order.setItems("Burger");
        order.setTotalAmount(300.0);
        order.setStatus(OrderStatus.PLACED);
        order.setOrderTime(OffsetDateTime.now());

        Mockito.when(orderRepository.findByCustomerId(1L)).thenReturn(List.of(order));

        List<OrderDTO> orders = orderService.getOrdersByCustomer(1L);

        assertEquals(1, orders.size());
        assertEquals("Burger", orders.get(0).getItems());
    }

    @Test
    void testUpdateOrderStatus() {
        Order order = new Order();
        order.setId(1L);
        order.setStatus(OrderStatus.PLACED);

        Mockito.when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        Mockito.when(orderRepository.save(Mockito.any(Order.class))).thenReturn(order);

        OrderDTO updated = orderService.updateOrderStatus(1L, OrderStatus.DELIVERED);

        assertEquals(OrderStatus.DELIVERED, updated.getStatus());
    }
}


