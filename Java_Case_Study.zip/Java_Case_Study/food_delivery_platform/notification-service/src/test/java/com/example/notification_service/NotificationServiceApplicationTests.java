package com.example.notification_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.notificationservice.NotificationServiceApplication;

@SpringBootTest(classes = NotificationServiceApplication.class)

class NotificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
