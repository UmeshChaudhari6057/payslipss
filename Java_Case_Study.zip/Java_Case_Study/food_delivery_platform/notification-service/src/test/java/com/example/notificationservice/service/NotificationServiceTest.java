package com.example.notificationservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.example.notificationservice.exception.InvalidNotificationTypeException;

class NotificationServiceTest {

    private final NotificationService notificationService = new NotificationService();

    @Test
    void testSendSmsNotification() {
        String response = notificationService.sendNotification("SMS", "1234567890", "Test SMS");
        assertEquals("SMS sent to 1234567890 with message: Test SMS", response);
    }

    @Test
    void testSendEmailNotification() {
        String response = notificationService.sendNotification("EMAIL", "user@example.com", "Test Email");
        assertEquals("Email sent to user@example.com with message: Test Email", response);
    }

    @Test
    void testSendPushNotification() {
        String response = notificationService.sendNotification("PUSH", "userDeviceToken", "Test Push");
        assertEquals("Push notification sent to userDeviceToken with message: Test Push", response);
    }

    @Test
    void testInvalidNotificationTypeThrowsException() {
        InvalidNotificationTypeException exception = assertThrows(
            InvalidNotificationTypeException.class,
            () -> notificationService.sendNotification("WHATSAPP", "user", "Test")
        );
        assertEquals("Unsupported notification type: WHATSAPP", exception.getMessage());
    }
}



