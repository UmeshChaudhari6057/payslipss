package com.example.notificationservice.service;

import org.springframework.stereotype.Service;

import com.example.notificationservice.exception.InvalidNotificationTypeException;

@Service
public class NotificationService {

    public String sendNotification(String type, String recipient, String message) {
        switch (type.toUpperCase()) {
            case "SMS":
                return sendSms(recipient, message);
            case "EMAIL":
                return sendEmail(recipient, message);
            case "PUSH":
                return sendPush(recipient, message);
            default:
            	throw new InvalidNotificationTypeException(type);
        }
    }

    private String sendSms(String recipient, String message) {
        // Simulate SMS sending
        return "SMS sent to " + recipient + " with message: " + message;
    }

    private String sendEmail(String recipient, String message) {
        // Simulate Email sending
        return "Email sent to " + recipient + " with message: " + message;
    }

    private String sendPush(String recipient, String message) {
        // Simulate Push Notification
        return "Push notification sent to " + recipient + " with message: " + message;
    }
}

