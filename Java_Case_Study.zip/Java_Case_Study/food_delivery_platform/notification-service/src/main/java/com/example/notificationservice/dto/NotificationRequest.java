package com.example.notificationservice.dto;

import jakarta.validation.constraints.NotBlank;

public class NotificationRequest {
	
	@NotBlank(message = "Notification type is required")
    private String type; // "SMS", "EMAIL", "PUSH"
	
	@NotBlank(message = "Recipient is required")
    private String recipient;
	
	@NotBlank(message = "Message is required")
    private String message;

    // Getters and Setters
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}

