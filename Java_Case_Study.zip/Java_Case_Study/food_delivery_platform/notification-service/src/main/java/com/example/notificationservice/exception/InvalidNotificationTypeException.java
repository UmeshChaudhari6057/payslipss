package com.example.notificationservice.exception;

public class InvalidNotificationTypeException extends RuntimeException {
    public InvalidNotificationTypeException(String type) {
        super("Unsupported notification type: " + type);
    }
}

