package com.example.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.user_service.UserServiceApplication;

@SpringBootTest(classes = UserServiceApplication.class)
class UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
