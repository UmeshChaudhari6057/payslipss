package com.example.user_service.service;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.user_service.dto.OrderDTO;
import com.example.user_service.dto.OrderStatus;
import com.example.user_service.dto.RestaurantDTO;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;



@Service
public class WebApiService {

	@Value("${restaurant.service.url}")
	private String restaurantServiceUrl;

	@Value("${order.service.url}")
	private String orderServiceUrl;

	@Value("${delivery.service.url}")
	private String deliveryServiceUrl;

	private final RestTemplate restTemplate;
	private final CircuitBreaker circuitBreaker;
	private final Retry retry;

	public WebApiService(RestTemplateBuilder builder, CircuitBreakerRegistry registry, RetryRegistry retryRegistry) {
		this.restTemplate = builder.build();
		this.circuitBreaker = registry.circuitBreaker("orderServiceCB");
		this.retry = retryRegistry.retry("orderServiceRetry");
	}

	public List<OrderDTO> getOrdersByCustomerId(Long customerId) {
        String url = orderServiceUrl + "/customer/" + customerId;

        Supplier<List<OrderDTO>> orderSupplier = () -> {
            ResponseEntity<List<OrderDTO>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<OrderDTO>>() {}
            );
            return response.getBody();
        };
     // Wrap with retry and circuit breaker
        Supplier<List<OrderDTO>> resilientSupplier = Decorators.ofSupplier(orderSupplier)
                .withRetry(retry)
                .withCircuitBreaker(circuitBreaker)
                .withFallback(throwable -> {
                    System.out.println("Fallback triggered: " + throwable.getMessage());
                    return getFallbackOrders(customerId);
                })
                .decorate();

        return resilientSupplier.get();
    }
	
	private List<OrderDTO> getFallbackOrders(Long customerId) {
        OrderDTO fallbackOrder = new OrderDTO();
        fallbackOrder.setId(-1L);
        fallbackOrder.setCustomerId(customerId);
        fallbackOrder.setStatus(OrderStatus.Something_went_wrong);
        fallbackOrder.setItems("");
        return Collections.singletonList(fallbackOrder);
    }

	public RestaurantDTO getRestaurantByName(String name) {
		String url = restaurantServiceUrl + "/" + name;
		return restTemplate.getForObject(url, RestaurantDTO.class);
	}

	/*
	 * public List<OrderDTO> getOrdersByCustomerId(Long customerId) { String url =
	 * orderServiceUrl + "/customer/" + customerId; ResponseEntity<List<OrderDTO>>
	 * response = restTemplate.exchange(url, HttpMethod.GET, null, new
	 * ParameterizedTypeReference<List<OrderDTO>>() { }); return response.getBody();
	 * }
	 */

	public OrderDTO trackOrdersByOrderIdandCustomerId(String orderId, Long customerId) {
		String url = deliveryServiceUrl + "/track/" + orderId + "/" + customerId;
		return restTemplate.getForObject(url, OrderDTO.class);
	}

}
