package com.example.user_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user_service.dto.OrderDTO;
import com.example.user_service.dto.RestaurantDTO;
import com.example.user_service.service.UserService;
import com.example.user_service.service.WebApiService;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private WebApiService webApiService;

	@Autowired
	private UserService userService;

	@GetMapping("/favorite-restaurant/{restaurantName}")
	public ResponseEntity<RestaurantDTO> getFavoriteRestaurant(@PathVariable String restaurantName) {
		return ResponseEntity.ok(webApiService.getRestaurantByName(restaurantName));
	}

	@GetMapping("/orders/{customerId}")
	public ResponseEntity<List<OrderDTO>> getOrders(@PathVariable Long customerId) {
		return ResponseEntity.ok(webApiService.getOrdersByCustomerId(customerId));
	}
	
	@GetMapping("/orders/{orderId}/customerId/{customerId}")
	public ResponseEntity <OrderDTO> trackOrders(@PathVariable String orderId, @PathVariable Long customerId) {
		return ResponseEntity.ok(webApiService.trackOrdersByOrderIdandCustomerId(orderId, customerId));
	}

}
