package com.example.user_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.user_service.dto.FoodOrderRequest;
import com.example.user_service.dto.FoodOrderResponse;
import com.example.user_service.dto.RegisterRequest;
import com.example.user_service.dto.RestaurantDTO;
import com.example.user_service.entity.User;
import com.example.user_service.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private WebClient.Builder webClientBuilder;

	public User register(RegisterRequest request) {
		User user = new User();
		user.setUsername(request.getUsername());
		user.setEmail(request.getEmail());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setRole("USER");
		return userRepository.save(user);
	}

	public User authenticate(String username) {
		return userRepository.findByUsername(username).orElseThrow();
	}

	

}
